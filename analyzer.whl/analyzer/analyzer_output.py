class JenkinsLogOutput:
    def print_results(self, results):
        print("")
        print("VISTA POR CATEGORIAS:")
        print("")
        size = self.print_header(["CATEGORIA","REGLA","RESULTADO","UMBRAL","VALOR ACTUAL"])           
        self.print_records(results)
        self.print_footer(size)
        print("")
        print("")     

    def print_header(self, header_columns):
        def fmt_cell(cell_value):
            return f"{str(cell_value):<28}"
        
        header_text = "|".join(list(map(fmt_cell, header_columns)))
        header_separator = "-"*len(header_text)
        print(header_text)
        print(header_separator)
        return len(header_text)       
    
    def print_records(self, records:list):  
        def fmt_cell(cell_value):
            return f"{str(cell_value):<28}"
        
        rows = sorted(records, key=lambda tup: tup[0])

        for row in rows:            
            print("|".join(list(map(fmt_cell, row))))

    def print_footer(self, size):
        header_separator = "-"*size
        print(header_separator) 