import glob
import os
import re
import csv
import pathlib
from dataclasses import dataclass
from datetime import date
from enum import Enum
import traceback
from analyzer.analyzer_core import AnalyzerCore
from analyzer.analyzer_core_scala import AnalyzerCoreScala
from analyzer.analyzer_core_json import AnalyzerCoreJSON
from analyzer.analyzer_core_sql import AnalyzerCoreSQL
import analyzer.analyzer_structure as structure
from analyzer.analyzer_config import CONST_CONFIG_RULES_INDEXED, CONST_CONFIG_ANALYZER_RESULT_CSV, CONST_CONFIG_RULES_KILL_JOB
from analyzer.analyzer_structure import RuleAnalysisResult, FileAnalysisResult
from analyzer.analyzer_utils import FileAnalysisContainer, RepoAnalysisContainer
import analyzer.analyzer_constants as constants
from analyzer.analyzer_output import JenkinsLogOutput
from analyzer.analyzer_whitelist import PYTHON_WHITE_LIST


@dataclass(frozen=True)
class Parameters(object):
    desarrollador: str = ""
    proveedor: str = ""
    po: str = ""
    fecha_pase: str = ""

class FileExplorer:
    def __init__(self, inputpath):
        self.inputpath = inputpath
        self.extensiones = ["py","scala","sql","json"]  
        # self.skip_folders = ["venv"]
        self.skip_items = ["venv","report_","checklist_","output","readme", "main", "app","execute_analyzer","reversion"]
        # self.skip_folder_paths = [pathlib.Path(os.path.join(inputpath,skip_folder)) for skip_folder in self.skip_folders]
        self.skip_item_paths = [os.path.normpath(os.path.join(inputpath,skip_item)) for skip_item in self.skip_items]
        # self.skip_folder_paths = [os.path.join(inputpath,skip_item) for skip_item in self.skip_items]
        
        # skip files
        self.skip_filnames = [
            "__init__.py",
            "__init__().py",
            "ANALYZER_V1.py",
            "analyzer.py",
            "analyzer_core.py",
            "analyzer_core_json.py",
            "analyzer_core_sql.py",
            "analyzer_core_scala.py",
            "analyzer_constants.py",
            "analyzer_config.py",
            "analyzer_response.py",
            "analyzer_output.py",
            "analyzer_structure.py",
            "analyzer_utils.py",
            "analyzer_whitelist.py",
            "coe_data_cleaner.py",
            "coedatacleaner_lockdownclean.py",
            "APPPYME_HM_SCOREAPPBASEPYMEMODULOCLIENTE.py",
            "APPPYME_HM_SCOREAPPBASEPYMEMODULORCC.py",
            "APPPYME_UM_INSUMORCCVARIABLEGEOGRAFICAAPPPYME.py",
            "ESTIMADORPYME_HM_ESTIMVTAFLUJONOVIGENTECORTESBS.py",
            "ESTIMADORPYME_HM_ESTIMADORFADPYME.py",
            "DTI_TRIGGERREPORTECUBO.py",
            "FCN_INTERACCIONCANALDIGITALTRANSACCIONCUBO.py",
            "FCN_INTERACCIONCANALPYCFCUBO.py",
            "FCN_INTERACCIONCANALPYCFCUBO_PRESUPUESTO.py",
            "FTE_CUADRETESORERIACLIENTETESORERIACUBO.py",
            "FTE_TESORERIACLIENTECUBO.py",
            "FTE_TESORERIACLIENTETESORERIACUBO.py",
            "F_CONTROLRUTINAJOB_PYCF.py",
            "F_CUADREREPORTEGESTIONGYPCONSUMOCUBO.py",
            "F_CUADREREPORTEGESTIONGYPMARCACONTRATOCUBO.py",
            "F_REPORTECUENTACUBO.py",
            "F_REPORTECUENTADESEMBOLSOCUBO.py",
            "F_REPORTECUENTAVENTACUBO.py",
            "F_REPORTECUENTAVENTASTOCKCUBO.py",
            "F_REPORTEGESTIONCLIENTECUBO.py",
            "F_REPORTEGESTIONCLIENTEDIGITALCUBO.py",
            "F_REPORTEGESTIONCOMISIONCUBO.py",
            "F_REPORTEGESTIONCONGESTCUBO.py",
            "F_REPORTEGESTIONCOSTOSERVCUBO.py",
            "F_REPORTEGESTIONCOSTOSERVCUBO_PRESUPUESTO.py",
            "F_REPORTEGESTIONCUBO.py",
            "F_REPORTEGESTIONCUBO_PRESUPUESTO.py",
            "F_REPORTEGESTIONDASHBOARDGYPCUBO.py",
            "F_REPORTEGESTIONDASHBOARDMARGENCUBO.py",
            "F_REPORTEGESTIONDASHBOARDVOLUMENCUBO.py",
            "F_REPORTEGESTIONDIGITALCUBO.py",
            "F_REPORTEGESTIONDIGITALCUBO_PRESUPUESTO.py",
            "F_REPORTEGESTIONGASTOCUBO.py",
            "F_REPORTEGESTIONGASTOOPERATIVOCUBO.py",
            "F_REPORTEGESTIONGYPCUBO.py",
            "F_REPORTEGESTIONGYPGAFICUBO.py",
            "F_REPORTEGESTIONGYPMARCACONTRATOCUBO.py",
            "F_REPORTEGESTIONGYPPRODUCTOCUBO.py",
            "F_REPORTEGESTIONGYPTARJETACUBO.py",
            "F_REPORTEGESTIONINGRESOSERVICIOCUBO.py",
            "F_REPORTEGESTIONMARGENCUBO.py",
            "F_REPORTEGESTIONPROVISIONNETACUBO.py",
            "F_REPORTEGESTIONRYPCUBO.py",
            "F_REPORTEGESTIONRYPCUBO_PRESUPUESTO.py",
            "F_REPORTEGESTIONSPREADDETALLADOCUBO.py",
            "F_REPORTEGESTIONTABLEROCONTROLCUBO.py",
            "F_REPORTEGESTIONVISTABANCACUBO.py",
            "F_REPORTEGESTIONVISTABCPCUBO.py",
            "F_REPORTEGESTIONVOLUMENCUBO.py"
        ]


    def filter_files(self, files):
        for filepath in files:            
            if not self.mark_to_skip(filepath=filepath):
                yield filepath
            
    def mark_to_skip(self, filepath):
        filepath = os.path.normpath(filepath)

        # skip folders
        for skip_item_path in self.skip_item_paths:
            if filepath.find(skip_item_path, 0) == 0:
                return True
        
        # skip files
        if pathlib.Path(filepath).name in self.skip_filnames:
            return True
            
        return False

        
    def find_files(self):        
        #procesamos los ficheros
        files_to_process = []
        for exten in self.extensiones:
            fullpath = os.path.join(self.inputpath, f"**/*.{exten}")
            files = glob.glob(fullpath, recursive=True)
            filtered_files = self.filter_files(files)
            files_to_process = files_to_process + list(filtered_files)
        return files_to_process
    
class ResultManager:
    def __init__(self, results):
        self.results = results

    def get_results(self):
        results = []
        for elem in self.results:
            if isinstance(elem, FileAnalysisResult):
                nu_record = self.file_analysys_to_record(elem)
                results.append(nu_record)
            else:
                results.append(elem)
        
        return results


    def file_analysys_to_record(self, file_analysis):
        record = []        
        for col_config in CONST_CONFIG_ANALYZER_RESULT_CSV:
            try:
                nom_col, nom_header = col_config
                value = getattr(file_analysis, nom_col)
                record.append(value)
            except AttributeError as ex:
                raise Exception(f"No se ha encontrado el campo {nom_col} en FileAnalysisResult")
            
        return record

    def exportar(self, outputpath):
        os.makedirs(outputpath, exist_ok=True)
        outputfile = os.path.join(outputpath,"Resultados.csv")
        with open(outputfile, "w", newline='') as csvfile:
            resultswriter = csv.writer(csvfile, delimiter=";")
            header = ["ruta_o","archivo","sufijo",
                      "distinct_number","collect_number","nested_query_number","with_column_number","topandas_number","select_all_number","spark_stop_number","remove_files_number",
                      "print_number","show_number","display_number","logger_number","dataframewriter_save_number","dataframereader_load_number","reasignacion_df_number", "dataflow_version_number",
                      "dataframe_rdd_number","dataframe_coalesce_mult_partitions_number","dataframe_count_number","dataframe_checkpoint_number","dataframe_repartition_number","print_dataframe_head_number",
                      "print_dataframe_collect_number", "print_dataframe_first_number", "print_dataframe_tail_number", "arquetype_version_number",
                      "po","proveedor","desarrollador","fecha_pase",
                      "user","per"]            
            resultswriter.writerow(header)
            resultswriter.writerows(self.get_results())

    def exportar_result(self, output_path, status_code):
        outputfile = os.path.join(output_path,"analyzer_execution_result.txt")
        with open(outputfile, "w", newline='') as res_file:
            res_file.write(f"STATUS_CODE={status_code}")

    def exportar_debug_data(self, output_path, debug_info:list=[]):
        outputfile = os.path.join(output_path,"analyzer_execution_debug.txt")
        with open(outputfile, encoding="utf8", mode="w") as debug_file:
            debug_file.write("\n".join(debug_info))

    def exportar_exceptions(self, output_path, errors_list):
        outputfile = os.path.join(output_path,"analyzer_execution_exceptions.txt")
        with open(outputfile, encoding="utf8", mode="w") as exceptions_file:
            exceptions_file.write("\n".join(errors_list))

            

class Analyzer:
    def __init__(self, inputpath="./", outputpath="output/", email_de=""):
        self.files = []
        self.results = []        
        self.inputpath = inputpath
        self.outputpath = outputpath
        self.email_de = email_de
        self.list_error_counts = []
        self.list_debug_data = []
        self.list_errors = []
        self.repo_analysis_container = None        

    def analizar(self):        
        result_manager = ResultManager(results=self.results)
        jenkins_log_output = JenkinsLogOutput()
        flg_error = False
        response_records = []
        
        try:
            file_explorer = FileExplorer(inputpath=self.inputpath)
            self.files = file_explorer.find_files()

            # procesamos los ficheros y guardamos los resultados
            self.repo_analysis_container = self.process_files()
            response_records = self.repo_analysis_container.gen_responses()

            # hacemos print del resultado en el log            
            jenkins_log_output.print_results(response_records) 

            # exportamos los resultados            
            result_manager.exportar(outputpath=self.outputpath)

        except Exception as ex:
            flg_error = True
            print("Analyzer no ha podido completar su ejecución, por favor comunicarse con el mantenedor de la herramienta")
            print(traceback.format_exc())
                    
        # Identificamos si es que en los resultados hay kill jobs pero si es que no hay errores
        if not flg_error:
            if self.is_kill_job(response_records):
                print("")
                print("Analyzer: Se han encontrado observaciones con criticidad alta que deben corregirse, para información sobre los umbrales y cuales reglas interrumpen el pipeline por favor revisar la sección III.e del instructivo https://bcp-ti.atlassian.net/wiki/spaces/LKDVDEPUB/pages/570461845/CoE+Data+Analyzer+-+Clasificaci+n+y+Criterios+de+Aceptaci+n")
                print("")
                # raise Exception("Analyzer Code: -1")
                result_manager.exportar_result(output_path=self.outputpath, status_code=-1)
            else:
                result_manager.exportar_result(output_path=self.outputpath, status_code=0)

            # generar el archivo de debug con información de la ejecución
            result_manager.exportar_debug_data(output_path=self.outputpath, debug_info=self.list_debug_data)

            # generar el archivo solo con las excepciones
            result_manager.exportar_exceptions(output_path=self.outputpath, errors_list=self.list_errors)

    def is_kill_job(self, results:list):

        for categoria, regla, resultado, umbral, error_count in results:
            if resultado == "FAILED (KILL JOB)":
                return True
            
        return False

    def get_file_contents(self, filepath):
        with open(filepath, "r", encoding="utf8") as file:
            return file.read()   

    
    def build_record(self, path, header_data: Parameters, error_counts):
        filepath = pathlib.Path(path)

        # errores
        # counts, bins, *otros = zip(*error_counts)

        #executors
        audit_data = (self.email_de, date.today().strftime("%Y%m"))

        # record = (path, filename, suffix) +  counts + hdata + bins + audit_data
        # record = (path, filename, suffix) +  counts + hdata + audit_data

        file_analysis = FileAnalysisResult(ruta=path,
                                    distinct_number=error_counts[0].num_observaciones,
                                    collect_number=error_counts[1].num_observaciones,
                                    nested_query_number=error_counts[2].num_observaciones,
                                    with_column_number=error_counts[3].num_observaciones,
                                    topandas_number=error_counts[4].num_observaciones,
                                    select_all_number=error_counts[5].num_observaciones,
                                    spark_stop_number=error_counts[6].num_observaciones,
                                    remove_files_number=error_counts[7].num_observaciones,
                                    print_number=error_counts[8].num_observaciones,
                                    show_number=error_counts[9].num_observaciones,
                                    display_number=error_counts[10].num_observaciones,
                                    logger_number=error_counts[11].num_observaciones,
                                    dataframewriter_save_number=error_counts[12].num_observaciones,
                                    dataframereader_load_number=error_counts[13].num_observaciones,
                                    reasignacion_df_number=error_counts[14].num_observaciones,
                                    dataframe_checkpoint_number=error_counts[15].num_observaciones,
                                    dataframe_count_number=error_counts[16].num_observaciones,
                                    print_dataframe_collect_number=error_counts[17].num_observaciones,
                                    print_dataframe_head_number=error_counts[18].num_observaciones,
                                    print_dataframe_first_number=error_counts[19].num_observaciones,
                                    print_dataframe_tail_number=error_counts[20].num_observaciones,
                                    dataframe_repartition_number=error_counts[21].num_observaciones,
                                    dataframe_coalesce_mult_partitions_number=error_counts[22].num_observaciones,
                                    dataframe_rdd_number=error_counts[23].num_observaciones,
                                    nom_product_owner=header_data.po,
                                    nom_proveedor=header_data.proveedor,
                                    nom_desarrollador=header_data.desarrollador,
                                    fch_pase=header_data.fecha_pase
                                    )
            
        return file_analysis
        

    def process_files(self):
        repo_analysis_container = RepoAnalysisContainer()

        for path in self.files:
            tip_fichero = pathlib.Path(path).suffix.lower()
            if tip_fichero == ".sql":
                self.analyze_sql(path)
            elif tip_fichero == ".scala":
                self.analyze_scala(path)
            elif tip_fichero == ".json":
                self.analyze_json(path)
            elif tip_fichero == ".py":
                self.analyze_python(path)
            else:
                self.add_handled_errors(path, f"archivo del tipo {tip_fichero} no soportado")

        # agrupar por repositorio
        repo_analysis_container.add_from_file_analysis_container_list(self.list_error_counts)
        return repo_analysis_container

    def add_rules_analysis_obs(self, rules_analysis_obs):
        self.list_error_counts.append(rules_analysis_obs)    

    def analyze_sql(self, filepath):
        analyzer = AnalyzerCoreSQL()
        file_analysis_result, rules_analysis_result = analyzer.analyze(filepath)

        file_analysis_container = FileAnalysisContainer(filepath)
        file_analysis_container.add_rule_analysis(rules_analysis_result)
        self.add_rules_analysis_obs(file_analysis_container)

        # de manera temporal agregar a results hasta que se cambie totalmente a la nueva estructura
        analyzer_result_record = analyzer.build_file_record(file_analysis_result)
        self.results.append(analyzer_result_record)

    def analyze_json(self, filepath):
        analyzer = AnalyzerCoreJSON(filepath)
        result = analyzer.analyze()
        if not result:
            return
        
        file_analysis_result, rules_analysis_result = result
        file_analysis_container = FileAnalysisContainer(filepath)
        file_analysis_container.add_rule_analysis(rules_analysis_result)
        self.add_rules_analysis_obs(file_analysis_container)

        # de manera temporal agregar a results hasta que se cambie totalmente a la nueva estructura
        analyzer_result_record = analyzer.build_file_record(file_analysis_result)
        self.results.append(analyzer_result_record)

    def analyze_scala(self, filepath):
        analyzer = AnalyzerCoreScala()
        result = analyzer.analyze(filepath)
        if not result:
            return
        
        file_analysis_result, rules_analysis_result = result
        file_analysis_container = FileAnalysisContainer(filepath)
        file_analysis_container.add_rule_analysis(rules_analysis_result)

        self.add_rules_analysis_obs(file_analysis_container)

        # de manera temporal agregar a results hasta que se cambie totalmente a la nueva estructura
        analyzer_result_record = analyzer.build_file_record(file_analysis_result)
        self.results.append(analyzer_result_record)

    def analyze_python(self, filepath):
        contents = self.get_file_contents(filepath=filepath)
        header_data = self.__get_data_header(data=contents)
        # ocultando los comentarios
        contents = contents.replace("pip install","# pip install")               
        error_counts, unhandled_error_type, unhandled_error, handled_errors, obs_details = self.analizar_contenido(filepath, contents)

        file_analysis_container = FileAnalysisContainer(filepath)
        file_analysis_container.add_rule_analysis(error_counts)

        # almacenamos el conteo de errores para luego clasificar        
        self.add_rules_analysis_obs(file_analysis_container)

        # construccion del registro para insertar
        record = self.build_record(path=filepath, header_data=header_data, error_counts=error_counts)
        self.results.append(record)

        # almacenamos si hay alguna excepción a la lista de excepciones
        if unhandled_error:
            self.add_unhandled_error(filepath, unhandled_error)
        if obs_details:
            self.add_obs_details(filepath, obs_details)
        if handled_errors:
            self.add_handled_errors(filepath, handled_errors)


    def add_unhandled_error(self, filepath, unhandled_error):
        self.list_errors.append(f"{filepath} - unhandled error: {unhandled_error}")

        
    def add_obs_details(self, filepath, all_obs_details):
        self.list_debug_data.append(f"{filepath} - obs details:")        
        for key, rule_details in all_obs_details.items():
            if len(rule_details) == 0:
                continue

            self.list_debug_data.append(f"rule: {key}")
            for elem in rule_details:
                self.list_debug_data.append(str(elem))

    def add_handled_errors(self, filepath, handled_errors):        
        # Guardando en errors para generar fichero separado
        self.list_errors.append(f"{filepath} - handled errors:")
        for item in handled_errors:
            self.list_errors.append(str(item))

    def analizar_contenido(self, filepath, contenido):
        filename = pathlib.Path(filepath).name  
        whitelist_excluded_rule_keys = PYTHON_WHITE_LIST.get(filename, [])      

        unhandled_error = None    
        unhandled_error_type = None    
        dataframewriter_save_number = 0
        dataframereader_load_number = 0
        reasignacion_df_number = 0
        dataframe_distinct = 0
        dataframe_collect = 0
        dataframe_topandas = 0    

        dataframe_rdd_number = 0
        dataframe_repartition_number = 0
        dataframe_coalesce_number = 0
        dataframe_count_number = 0
        dataframe_checkpoint_number = 0
        print_dataframe_collect_number = 0
        print_dataframe_head_number = 0        
        print_dataframe_first_number = 0
        print_dataframe_tail_number = 0

        obs = None
        handled_errors = []
        global_exclusions = []
        exclusions = []
        error_counts = []

        #Obtenemos las exclusiones
        core = AnalyzerCore()
        
        try:            
            global_exclusions, exclusions = core.get_exclusiones(contenido)            
            obs, handled_errors = core.analizar(contenido, global_exclusions=global_exclusions, exclusions=exclusions)
            # obs_details_list = core.get_obs_details_as_list(obs)

            dataframewriter_save_number = len(obs[constants.CONST_RULE_KEY_DATAFRAMEWRITER_SAVE])
            dataframereader_load_number = len(obs[constants.CONST_RULE_KEY_DATAFRAMEREADER_LOAD])
            reasignacion_df_number = len(obs[constants.CONST_RULE_KEY_DATAFRAME_REASIGNACION])
            dataframe_distinct = len(obs[constants.CONST_RULE_KEY_DISTINCT])
            dataframe_collect = len(obs[constants.CONST_RULE_KEY_COLLECT])
            dataframe_topandas = len(obs[constants.CONST_RULE_KEY_TOPANDAS])
            print_dataframe_collect_number = len(obs[constants.CONST_RULE_KEY_PRINT_DATAFRAME_COLLECT]) 
            print_dataframe_head_number = len(obs[constants.CONST_RULE_KEY_PRINT_DATAFRAME_HEAD])           
            print_dataframe_first_number = len(obs[constants.CONST_RULE_KEY_PRINT_DATAFRAME_FIRST])
            print_dataframe_tail_number = len(obs[constants.CONST_RULE_KEY_PRINT_DATAFRAME_TAIL])
            dataframe_rdd_number = len(obs[constants.CONST_RULE_KEY_DATAFRAME_RDD])
            dataframe_repartition_number = len(obs[constants.CONST_RULE_KEY_DATAFRAME_REPARTITION])
            dataframe_coalesce_number = len(obs[constants.CONST_RULE_KEY_DATAFRAME_COALESCE_MULTIPLE_PARTITIONS])
            dataframe_count_number = len(obs[constants.CONST_RULE_KEY_DATAFRAME_COUNT])
            dataframe_checkpoint_number = len(obs[constants.CONST_RULE_KEY_DATAFRAME_CHECKPOINT])

        except Exception as e:  
            unhandled_error_type = type(e).__name__
            unhandled_error = f"exception: {str(e)}, traceback: {traceback.format_exc()}"
            
        contenido = contenido.lower()
        
        error_counts.append(self.gen_stats_dataframe_distinct(dataframe_distinct, whitelist_excluded_rule_keys=whitelist_excluded_rule_keys))
        error_counts.append(self.gen_stats_dataframe_collect(dataframe_collect))
        error_counts.append(self.analizar_nested_query(contenido=contenido, global_exclusions=global_exclusions, whitelist_excluded_rule_keys=whitelist_excluded_rule_keys))
        error_counts.append(self.analizar_withcolumn(contenido=contenido, global_exclusions=global_exclusions))
        error_counts.append(self.gen_stats_dataframe_to_pandas(dataframe_topandas))
        error_counts.append(self.analizar_select_all(contenido=contenido, global_exclusions=global_exclusions))        
        error_counts.append(self.analizar_spark_stop(contenido=contenido))
        error_counts.append(self.analizar_remove_files(contenido=contenido))
        error_counts.append(self.analizar_print(contenido=contenido, global_exclusions=global_exclusions))
        error_counts.append(self.analizar_show(contenido=contenido))
        error_counts.append(self.analizar_display(contenido=contenido))
        error_counts.append(self.analizar_logger(contenido=contenido, global_exclusions=global_exclusions))
        error_counts.append(self.gen_stats_dataframewriter_save(dataframewriter_save_number))
        error_counts.append(self.gen_stats_dataframereader_load(dataframereader_load_number))
        error_counts.append(self.gen_stats_reasignacion_df(reasignacion_df_number))

        error_counts.append(self.gen_stats_dataframe_checkpoint(dataframe_checkpoint_number))
        error_counts.append(self.gen_stats_dataframe_count(dataframe_count_number))
        error_counts.append(self.gen_stats_print_dataframe_collect(print_dataframe_collect_number) )
        error_counts.append(self.gen_stats_print_dataframe_head(print_dataframe_head_number))
        error_counts.append(self.gen_stats_print_dataframe_first(print_dataframe_first_number))
        error_counts.append(self.gen_stats_print_dataframe_tail(print_dataframe_tail_number) )
        error_counts.append(self.gen_stats_dataframe_repartition(dataframe_repartition_number))
        error_counts.append(self.gen_stats_dataframe_coalesce(dataframe_coalesce_number))
        error_counts.append(self.gen_stats_dataframe_rdd(dataframe_rdd_number))
                        
        return error_counts, unhandled_error_type, unhandled_error, handled_errors, obs
    
    def analizar_distinct(self, contenido):        
        count =  len(re.findall(r"distinct", contenido))                
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DISTINCT, num_observaciones=count)
        return result        
    
    def gen_stats_dataframe_distinct(self, distinct_number, whitelist_excluded_rule_keys):                              
        count = distinct_number
        if constants.CONST_RULE_KEY_DISTINCT in whitelist_excluded_rule_keys:
            count = 0

        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DISTINCT, num_observaciones=count)
        return result

    def gen_stats_dataframe_collect(self, collect_number):            
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_COLLECT, num_observaciones=collect_number)
        return result

    def gen_stats_dataframe_to_pandas(self, to_pandas_number):        
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_TOPANDAS, num_observaciones=to_pandas_number)
        return result        

    def analizar_withcolumn(self, contenido, global_exclusions):
        rule_config = CONST_CONFIG_RULES_INDEXED.get(constants.CONST_RULE_KEY_WITHCOLUMN)

        count = len(re.findall(
                    r"\.withcolumn|"
                    r"\.\\\s*\n\s*withcolumn"
                    ,contenido))
        
        if rule_config.token_exclusion_global in global_exclusions:
            count = 0

        # label = self.get_range_label(bounds=self.__rangeswithcol, count=count)    
        # return (count, label, Categoria.OPTIMIZACION.value, Criticidad.MEDIA.value, Regla.WITHCOLUMN.value, 5, 5)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_WITHCOLUMN, num_observaciones=count)
        return result    

    def analizar_nested_query(self, contenido, global_exclusions, whitelist_excluded_rule_keys=[]):
        rule_config = CONST_CONFIG_RULES_INDEXED.get(constants.CONST_RULE_KEY_NESTED_QUERY)

        count = len(re.findall(
                    r"from\s+\(\s+select|"
                    r"from\s+\(select|"
                    r"from\(\s+select|"
                    r"from\(select|"
                    r"in\s+\(select|"
                    r"in\(select|"
                    r"in\(\s+select|"
                    r"join\s+\(select|"
                    r"join\(select|"
                    r"join\(\s+select|"
                    r"\.join\(\s+\.select|"
                    r"\.join\s+\(\.select|"
                    r"\.join\(\.select",
                    contenido))

        if constants.CONST_RULE_KEY_NESTED_QUERY in whitelist_excluded_rule_keys:
            count = 0
        
        if rule_config.token_exclusion_global in global_exclusions:
            count = 0

        # label = self.get_range_label(bounds=self.__rangesorig, count=count)
        # return (count, label, Categoria.CALIDAD_CODIGO.value, Criticidad.ALTA.value, Regla.NESTED_QUERY.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_NESTED_QUERY, num_observaciones=count)
        return result

    def analizar_spark_stop(self, contenido):
        count = len(re.findall(r"^(?!#)\s*spark\.stop", contenido, re.MULTILINE))
        # label = self.get_range_label(bounds=self.__rangesorig, count=count)
        # return (count, label, Categoria.CALIDAD_CODIGO.value, Criticidad.ALTA.value,Regla.SPARK_STOP.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_SPARK_STOP, num_observaciones=count)
        return result

    def analizar_select_all(self, contenido, global_exclusions):
        rule_config = CONST_CONFIG_RULES_INDEXED.get(constants.CONST_RULE_KEY_SELECT_ALL)
        count = len(re.findall(r"select\s+\*\s+from", contenido))

        if rule_config.token_exclusion_global in global_exclusions:
            count = 0

        # label = self.get_range_label(bounds=self.__rangesorig, count=count)
        # return (count, label, Categoria.OPTIMIZACION.value, Criticidad.ALTA.value, Regla.SELECT_ALL.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_SELECT_ALL, num_observaciones=count)
        return result
    
    def analizar_remove_files(self, contenido):
        count = len(re.findall(r"(dbutils\.fs\.rm|"
                          r"directory_client\.delete_directory|"
                          r"%fs\s+rm)", contenido))
        # label = self.get_range_label(bounds=self.__rangesorig, count=count)
        # return (count, label, Categoria.CALIDAD_CODIGO.value, Criticidad.ALTA.value,Regla.REMOVE_FILES.value, 0,0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_REMOVE_FILES, num_observaciones=count)
        return result

    def analizar_print(self, contenido, global_exclusions):
        rule_config =  CONST_CONFIG_RULES_INDEXED.get(constants.CONST_RULE_KEY_PRINT)       
        # Se pone magic en lugar de MAGIC porque todo el contenido se convierte a minusculas
        count = len(re.findall(r"^(?!#)\s*print\(.*|--\s+magic\s+print\(.*",contenido, re.MULTILINE))
        if rule_config.token_exclusion_global in global_exclusions:            
            count = 0

        # label = self.get_range_label(bounds=self.__rangesorig, count=count)        
        # return (count, label, Categoria.SEGURIDAD.value, Criticidad.BAJA.value, Regla.PRINT.value, 15,15)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_PRINT, num_observaciones=count)
        return result

    def analizar_show(self, contenido):
        count = len(re.findall(r"^(?!#)\s*.+\.show\(",contenido, re.MULTILINE))
        # label = self.get_range_label(bounds=self.__rangesorig, count=count)        
        # return (count, label, Categoria.SEGURIDAD.value, Criticidad.ALTA.value, Regla.SHOW.value, 0,0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_SHOW, num_observaciones=count)
        return result

    def analizar_display(self, contenido):
        count = len(re.findall(r"^(?!#)\s*display\(.*",contenido, re.MULTILINE))
        # label = self.get_range_label(bounds=self.__rangesorig, count=count)        
        # return (count, label, Categoria.SEGURIDAD.value, Criticidad.ALTA.value,Regla.DISPLAY.value, 0,0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DISPLAY, num_observaciones=count)
        return result
    
    def analizar_logger(self, contenido, global_exclusions):
        rule_config = CONST_CONFIG_RULES_INDEXED.get(constants.CONST_RULE_KEY_LOGGER)
        count = len(re.findall(r"^(?!#)\s*.+\.(info\(.*|debug\(.*|warning\(.*)", contenido, re.MULTILINE))        

        if rule_config.token_exclusion_global in global_exclusions:
            count = 0

        # label = self.get_range_label(bounds=self.__rangesorig, count=count)                
        # return (count, label, Categoria.SEGURIDAD.value, Criticidad.BAJA.value, Regla.LOGGER.value, 15,15)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_LOGGER, num_observaciones=count)
        return result

    # se va a deprecar este metodo
    def analizar_teams_msg(self, contenido):
        count = len(re.findall(r"\"@type\"\s*:\s*\"messagecard\"", contenido))
        label = self.get_range_label(bounds=self.__rangesorig, count=count)
        return (count, label, constants.CONST_CATEGORIA_SEGURIDAD, constants.CONST_CRITICIDAD_MEDIA, "teams mgs number (deprecar)", 2,2)
    
    def gen_stats_dataframewriter_save(self, dataframewriter_save_number):
        #label = self.get_range_label(bounds=self.__rangesorig, count=dataframewriter_save_number)
        # return (dataframewriter_save_number, label, Categoria.GOBIERNO.value, Criticidad.ALTA.value, Regla.DATAFRAMEWRITER_SAVE.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DATAFRAMEWRITER_SAVE, num_observaciones=dataframewriter_save_number)
        return result
    
    def gen_stats_dataframereader_load(self, dataframereader_load_number):
        # label = self.get_range_label(bounds=self.__rangesorig, count=dataframereader_load_number)
        # return (dataframereader_load_number, label, Categoria.GOBIERNO.value, Criticidad.ALTA.value, Regla.DATAFRAMEREADER_LOAD.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DATAFRAMEREADER_LOAD, num_observaciones=dataframereader_load_number)
        return result
    
    def gen_stats_reasignacion_df(self, reasignacion_df_number):
        # label = self.get_range_label(bounds=self.__rangesorig, count=reasignacion_df_number)
        # return (reasignacion_df_number, label, Categoria.GOBIERNO.value, Criticidad.ALTA.value, Regla.REASIGNACION_DF.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DATAFRAME_REASIGNACION, num_observaciones=reasignacion_df_number)        
        return result
    
    def gen_stats_dataframe_checkpoint(self, dataframe_checkpoint_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=dataframe_checkpoint_number)    
        #return (dataframe_checkpoint_number, label, Categoria.OPTIMIZACION.value, Criticidad.ALTA.value, Regla.DATAFRAME_CHECKPOINT.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DATAFRAME_CHECKPOINT, num_observaciones=dataframe_checkpoint_number)        
        return result  
    
    def gen_stats_dataframe_repartition(self, dataframe_repartition_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=dataframe_repartition_number)    
        #return (dataframe_repartition_number, label, Categoria.OPTIMIZACION.value, Criticidad.ALTA.value, Regla.DATAFRAME_REPARTITION.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DATAFRAME_REPARTITION, num_observaciones=dataframe_repartition_number)        
        return result  
    
    def gen_stats_dataframe_coalesce(self, dataframe_coalesce_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=dataframe_coalesce_number)    
        #return (dataframe_coalesce_number, label, Categoria.OPTIMIZACION.value, Criticidad.ALTA.value, Regla.DATAFRAME_COALESCE.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DATAFRAME_COALESCE_MULTIPLE_PARTITIONS, num_observaciones=dataframe_coalesce_number)        
        return result  
    
    def gen_stats_dataframe_rdd(self, dataframe_rdd_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=dataframe_rdd_number)    
        #return (dataframe_rdd_number, label, Categoria.OBSOLESCENCIA.value, Criticidad.BAJA.value, Regla.DATAFRAME_RDD.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DATAFRAME_RDD, num_observaciones=dataframe_rdd_number)        
        return result  
    
    def gen_stats_print_dataframe_collect(self, print_dataframe_collect_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=print_dataframe_collect_number)    
        #return (print_dataframe_collect_number, label, Categoria.SEGURIDAD.value, Criticidad.ALTA.value, Regla.PRINT_DATAFRAME_COLLECT.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_PRINT_DATAFRAME_COLLECT, num_observaciones=print_dataframe_collect_number)        
        return result
    
    def gen_stats_print_dataframe_head(self, print_dataframe_head_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=print_dataframe_head_number)    
        #return (print_dataframe_head_number, label, Categoria.SEGURIDAD.value, Criticidad.ALTA.value, Regla.PRINT_DATAFRAME_HEAD.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_PRINT_DATAFRAME_HEAD, num_observaciones=print_dataframe_head_number)        
        return result
    

    def gen_stats_print_dataframe_first(self, print_dataframe_first_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=print_dataframe_first_number)    
        #return (print_dataframe_first_number, label, Categoria.SEGURIDAD.value, Criticidad.ALTA.value, Regla.PRINT_DATAFRAME_FIRST.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_PRINT_DATAFRAME_FIRST, num_observaciones=print_dataframe_first_number)        
        return result

    def gen_stats_print_dataframe_tail(self, print_dataframe_tail_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=print_dataframe_tail_number)    
        #return (print_dataframe_tail_number, label, Categoria.SEGURIDAD.value, Criticidad.ALTA.value, Regla.PRINT_DATAFRAME_TAIL.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_PRINT_DATAFRAME_TAIL, num_observaciones=print_dataframe_tail_number)        
        return result
    
    def gen_stats_dataframe_count(self, dataframe_count_number): 
        #label = self.get_range_label(bounds=self.__rangesorig, count=dataframe_count_number)    
        #return (dataframe_count_number, label, Categoria.OPTIMIZACION.value, Criticidad.MEDIA.value, Regla.DATAFRAME_COUNT.value, 0, 0)
        result = RuleAnalysisResult(constants.CONST_RULE_KEY_DATAFRAME_COUNT, num_observaciones=dataframe_count_number)        
        return result   


    def __get_data_header(self, data) -> Parameters:
        data = data.lower()
        info_cabecera = re.findall(r"# \|\|\s+[0-9]+[^\n]+|-- \|\|\s+[0-9]+[^\n]+|--\|\|\s+[0-9]+[^\n]+", data)
        if info_cabecera:
            try:
                data_user = info_cabecera[-2].split() if re.findall(r"\*\*\*|---", info_cabecera[-1]) else \
                    info_cabecera[-1].split()
            except IndexError as e:
                data_user = info_cabecera[-1]

            empresa = self.__get_proveedor_regex(data_user)
            if empresa:
                return self.__with_empresa(data_user, empresa[0])

            else:
                return self.__without_empresa(data_user)
        else:
            return Parameters()
        
    @staticmethod
    def __get_proveedor_regex(data: str) -> list:        
        return re.findall(r"everis|ms|indra|bcp|bluetab", " ".join(data))
    
    def __with_empresa(self, data_user: str, empresa: str) -> Parameters:
        empresas = " ".join(data_user).split(empresa)
        fecha = self.__get_date_regex(empresas[1])
        po = ""
        fecha_pase = ""
        desarrollador = " ".join(empresas[0].split()[2:]) if '--||' in empresas[0] else " ".join(
            empresas[0].split()[3:])

        if fecha:
            fechas = empresas[1].split(fecha[0])
            po = fechas[0]
            fecha_pase = fecha[0]

        return Parameters(desarrollador, empresa, po, fecha_pase)
    
    def __without_empresa(self, data_user: str) -> Parameters:
        fecha = self.__get_date_regex(" ".join(data_user))
        fecha_pase = ""
        desarrollador = ""

        if fecha:
            fechas = " ".join(data_user).split(fecha[0])
            desarrollador = " ".join(fechas[0].split()[3:])
            fecha_pase = fecha[0]

        return Parameters(desarrollador, "No definido", "No definido", fecha_pase)
    
    @staticmethod
    def __get_date_regex(data: str) -> list:
        return re.findall(r"\d{2,4}[-/]\d{1,2}[-/]\d{1,4}", data)

    