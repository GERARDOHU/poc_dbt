import analyzer.analyzer_constants as constants



class ConfiguracionRegla:
    def __init__(self, id_regla, nom_regla, nom_categoria, nom_criticidad, umbral=0, flg_kill_job=True, token_exclusion=None, token_exclusion_global=None, flg_pre_despliegue = False):
        self.id_regla = id_regla
        self.nom_regla = nom_regla
        self.nom_categoria = nom_categoria
        self.nom_criticidad = nom_criticidad
        self.umbral = umbral
        self.flg_kill_job = flg_kill_job
        self.token_exclusion = token_exclusion
        self.token_exclusion_global = token_exclusion_global
        self.flg_pre_despliegue = flg_pre_despliegue

CONST_CONFIG_RULES = [
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_SHOW, nom_regla=constants.CONST_RULE_SHOW, nom_categoria=constants.CONST_CATEGORIA_SEGURIDAD, nom_criticidad=constants.CONST_CRITICIDAD_ALTA),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DISPLAY, nom_regla=constants.CONST_RULE_DISPLAY, nom_categoria=constants.CONST_CATEGORIA_SEGURIDAD, nom_criticidad=constants.CONST_CRITICIDAD_ALTA),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_REMOVE_FILES, nom_regla=constants.CONST_RULE_REMOVE_FILES, nom_categoria=constants.CONST_CATEGORIA_CALIDAD_CODIGO, nom_criticidad=constants.CONST_CRITICIDAD_ALTA),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_PRINT, nom_regla=constants.CONST_RULE_PRINT, nom_categoria=constants.CONST_CATEGORIA_SEGURIDAD, nom_criticidad=constants.CONST_CRITICIDAD_BAJA, umbral=15, token_exclusion_global=constants.CONST_TOKEN_EXCLUSION_PRINT),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_LOGGER, nom_regla=constants.CONST_RULE_LOGGER, nom_categoria=constants.CONST_CATEGORIA_SEGURIDAD, nom_criticidad=constants.CONST_CRITICIDAD_BAJA, umbral=15, token_exclusion_global=constants.CONST_TOKEN_EXCLUSION_LOGGER),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DISTINCT, nom_regla=constants.CONST_RULE_DISTINCT, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_DISTINCT),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_COLLECT, nom_regla=constants.CONST_RULE_COLLECT, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_COLLECT),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_TOPANDAS, nom_regla=constants.CONST_RULE_TOPANDAS, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_TO_PANDAS),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_SELECT_ALL, nom_regla=constants.CONST_RULE_SELECT_ALL, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion_global=constants.CONST_TOKEN_EXCLUSION_SELECT_ALL),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_WITHCOLUMN, nom_regla=constants.CONST_RULE_WITHCOLUMN, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_MEDIA, umbral=5, token_exclusion_global=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_WITHCOLUMN),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFRAMEWRITER_SAVE, nom_regla=constants.CONST_RULE_DATAFRAMEWRITER_SAVE, nom_categoria=constants.CONST_CATEGORIA_GOBIERNO, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_WRITER_SAVE),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFRAMEREADER_LOAD, nom_regla=constants.CONST_RULE_KEY_DATAFRAMEREADER_LOAD, nom_categoria=constants.CONST_CATEGORIA_GOBIERNO, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_READER_LOAD),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFRAME_REASIGNACION, nom_regla=constants.CONST_RULE_REASIGNACION_DF, nom_categoria=constants.CONST_CATEGORIA_GOBIERNO, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_REASIGNACION),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_SPARK_STOP, nom_regla=constants.CONST_RULE_SPARK_STOP, nom_categoria=constants.CONST_CATEGORIA_CALIDAD_CODIGO, nom_criticidad=constants.CONST_CRITICIDAD_ALTA),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_NESTED_QUERY,  nom_regla=constants.CONST_RULE_NESTED_QUERY, nom_categoria=constants.CONST_CATEGORIA_CALIDAD_CODIGO, nom_criticidad=constants.CONST_CRITICIDAD_MEDIA, token_exclusion_global=constants.CONST_TOKEN_EXCLUSION_NESTED_QUERY),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFLOW_VERSION, nom_regla=constants.CONST_RULE_DATAFLOW_VERSION, nom_categoria=constants.CONST_CATEGORIA_OBSOLESCENCIA, nom_criticidad=constants.CONST_CRITICIDAD_ALTA),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFRAME_RDD, nom_regla=constants.CONST_RULE_DATAFRAME_RDD, nom_categoria=constants.CONST_CATEGORIA_OBSOLESCENCIA, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, flg_kill_job=True, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFRAME_COALESCE_MULTIPLE_PARTITIONS, nom_regla=constants.CONST_RULE_DATAFRAME_COALESCE_MULTIPLE_PARTITIONS, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_COALESCE_MULT_PART, flg_kill_job=True, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFRAME_COUNT, nom_regla=constants.CONST_RULE_DATAFRAME_COUNT, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, flg_kill_job=False, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFRAME_CHECKPOINT, nom_regla=constants.CONST_RULE_DATAFRAME_CHECKPOINT, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_CHECKPOINT, flg_kill_job=True, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_DATAFRAME_REPARTITION, nom_regla=constants.CONST_RULE_DATAFRAME_REPARTITION, nom_categoria=constants.CONST_CATEGORIA_OPTIMIZACION, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, token_exclusion=constants.CONST_TOKEN_EXCLUSION_DATAFRAME_REPARTITION,  flg_kill_job=True, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_PRINT_DATAFRAME_HEAD, nom_regla=constants.CONST_RULE_PRINT_DATAFRAME_HEAD, nom_categoria=constants.CONST_CATEGORIA_SEGURIDAD, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, flg_kill_job=True, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_PRINT_DATAFRAME_COLLECT, nom_regla=constants.CONST_RULE_PRINT_DATAFRAME_COLLECT, nom_categoria=constants.CONST_CATEGORIA_SEGURIDAD, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, flg_kill_job=True, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_PRINT_DATAFRAME_FIRST, nom_regla=constants.CONST_RULE_PRINT_DATAFRAME_FIRST, nom_categoria=constants.CONST_CATEGORIA_SEGURIDAD, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, flg_kill_job=True, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_PRINT_DATAFRAME_TAIL, nom_regla=constants.CONST_RULE_PRINT_DATAFRAME_TAIL, nom_categoria=constants.CONST_CATEGORIA_SEGURIDAD, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, flg_kill_job=True, flg_pre_despliegue=False),
    ConfiguracionRegla(id_regla=constants.CONST_RULE_KEY_ARQUETYPE_VERSION, nom_regla=constants.CONST_RULE_ARQUETYPE_VERSION, nom_categoria=constants.CONST_CATEGORIA_OBSOLESCENCIA, nom_criticidad=constants.CONST_CRITICIDAD_ALTA, flg_kill_job=True)
]

# Reglas en un diccionario con la clave de la regla
CONST_CONFIG_RULES_INDEXED = {rule_config.id_regla: rule_config for rule_config in CONST_CONFIG_RULES}

# Reglas en una lista aquellas claves que hacen kill job
CONST_CONFIG_RULES_KILL_JOB = [rule_config.id_regla for rule_config in CONST_CONFIG_RULES if rule_config.flg_kill_job == True]

# Reglas que tienen token de exclusion por linea, indexadas por token de exclusion
CONST_CONFIG_RULES_TOKEN_EXCLUSION_INDEXED = {rule_config.token_exclusion: rule_config for rule_config in CONST_CONFIG_RULES if rule_config.token_exclusion is not None}

# Reglas que tienen token de exclusion por fichero, indexadas por token de exclusion
CONST_CONFIG_RULES_TOKEN_EXCLUSION_GLOBAL_INDEXED = {rule_config.token_exclusion_global: rule_config for rule_config in CONST_CONFIG_RULES if rule_config.token_exclusion_global is not None}

# Reglas que estan en pre-despliegue
CONST_CONFIG_RULES_PRE_DEPLOY = [rule_config.id_regla for rule_config in CONST_CONFIG_RULES if rule_config.flg_pre_despliegue == True]

# Analyzer result csv format
# nom_columna, nom_cabecera
CONST_CONFIG_ANALYZER_RESULT_CSV = [
    ("ruta", "ruta"),
    ("archivo", "archivo"),
    ("sufijo", "sufijo"),
    ("distinct_number", "distinct_number"),
    ("collect_number", "collect_number"),
    ("nested_query_number", "nested_query_number"),
    ("with_column_number", "with_column_number"),
    ("topandas_number", "topandas_number"),
    ("select_all_number","select_all_number"),
    ("spark_stop_number", "spark_stop_number"),
    ("remove_files_number", "remove_files_number"),
    ("print_number", "print_number"),
    ("show_number", "show_number"),
    ("display_number", "display_number"),
    ("logger_number", "logger_number"),
    ("dataframewriter_save_number", "dataframewriter_save_number"),
    ("dataframereader_load_number", "dataframereader_load_number"),
    ("reasignacion_df_number", "reasignacion_df_number"),
    ("dataflow_version_number", "dataflow_version_number"),
    ("dataframe_rdd_number","dataframe_rdd_number"),
    ("dataframe_coalesce_mult_partitions_number","dataframe_coalesce_mult_partitions_number"),
    ("dataframe_count_number","dataframe_count_number"),
    ("dataframe_checkpoint_number","dataframe_checkpoint_number"),
    ("dataframe_repartition_number","dataframe_repartition_number"),
    ("print_dataframe_head_number","print_dataframe_head_number"),
    ("print_dataframe_collect_number","print_dataframe_collect_number"),
    ("print_dataframe_first_number","print_dataframe_first_number"),
    ("print_dataframe_tail_number","print_dataframe_tail_number"),
    ("arquetype_version_number","arquetype_version_number"),
    ("nom_product_owner", "nom_product_owner"),
    ("nom_proveedor", "nom_proveedor"),
    ("nom_desarrollador", "nom_desarrollador"),
    ("fch_pase", "fch_pase")
]

# Configuración de Atributos
CONST_CONFIG_AST_ATTRIBUTE = {        
    "DefaultValueOnlyWidgetUtils.text":None,
    "DefaultValueOnlyWidgetUtils.get":"str",
    "RemoteDbUtils.widgets":"DefaultValueOnlyWidgetUtils", 
    "dbutils.widgets.get":"str",
    # SparkSession
    "SparkSession.read":"DataFrameReader",
    "SparkSession.sql":"DataFrame",
    "SparkSession.createDataFrame":"DataFrame",
    "SparkSession.table":"DataFrame",
    # DataFrameReader
    "DataFrameReader.format": "DataFrameReader",
    "DataFrameReader.load": "DataFrameReader",        
    "DataFrameReader.option": "DataFrameReader", 
    "DataFrameReader.table": "DataFrame",
    # DataFrame             
    "DataFrame.write":"DataFrameWriter",
    "DataFrame.filter":"DataFrame",
    "DataFrame.join":"DataFrame",
    "DataFrame.count":"int",                    #AGREGUE
    "DataFrame.checkpoint":"DataFrame",         #AGREGUE
    "DataFrame.repartition":"DataFrame",        #AGREGUE
    "DataFrame.head":"list",                    #AGREGUE
    "DataFrame.collect":"list",                 #AGREGUE
    "DataFrame.first":None,                     #AGREGUE
    "DataFrame.tail":None,                      #AGREGUE  
    # DataFrameWriter
    "DataFrameWriter.mode":"DataFrameWriter",
    "DataFrameWriter.format":"DataFrameWriter",
    "DataFrameWriter.option":"DataFrameWriter",
    "DataFrameWriter.partitionBy":"DataFrameWriter",
    "DataFrameWriter.save":None,
    # str
    "str.replace":"str",
    "str.lower":"str",
    "str.join":"str",
    "str.split":"list"
}

# Configuración de Call
CONST_CONFIG_AST_CALL = {
    # StructType
    "StructType":("StructType", None),
    "StructField": ("StructField", None),
    # DataFrameReader
    "DataFrameReader.load":("DataFrame","_dataframereader_load"),
    "DataFrameReader.format":("DataFrameReader","_dataframereader_format"),
    "DataFrameReader.table":("DataFrame","_spark_session_table"),
    "DataFrameReader.option":("DataFrameReader", None),
    "DataFrameReader.csv":("DataFrame",None),
    "DataFrameReader.parquet":("DataFrame", None),
    # DefaultValueOnlyWidgetUtils
    "DefaultValueOnlyWidgetUtils.text":(None, "_dbutils_widgets_text"),
    "DefaultValueOnlyWidgetUtils.get":("str", "_dbutils_widgets_get"),
    # SparkSession
    "SparkSession.table":("DataFrame","_spark_session_table"),
    "SparkSession.sql":("DataFrame","_spark_session_sql"),
    "SparkSession.createDataFrame":("DataFrame",None),
    # DataFrame
    "DataFrame.first":("Row",None), 
    "DataFrame.filter":("DataFrame",None),
    "DataFrame.count":("int","_dataframe_count"),  
    "DataFrame.select":("DataFrame",None),
    "DataFrame.alias":("DataFrame",None),
    "DataFrame.join":("DataFrame",None),
    "DataFrame.take":("list",None),        
    "DataFrame.toPandas":("pandas.DataFrame","_dataframe_topandas"),
    "DataFrame.collect":("list","_dataframe_collect"),
    "DataFrame.distinct":("DataFrame","_dataframe_distinct"),
    "DataFrame.persist":("DataFrame", None),   
    "DataFrame.show":("DataFrame", None),   
    "DataFrame.union":("DataFrame", None),   
    "DataFrame.unionAll":("DataFrame", None),
    "DataFrame.createOrReplaceTempView":(None, None),
    "DataFrame.drop_duplicates":("DataFrame", None),                
    "DataFrame.groupBy":("GroupedData",None),        
    "DataFrame.groupby":("GroupedData",None),        
    "DataFrame.drop":("DataFrame",None),
    "DataFrame.cache":("DataFrame",None),
    "DataFrame.where":("DataFrame",None),
    "GroupedData.agg":("DataFrame",None),
    "DataFrame.head":("list",None),     
    "DataFrame.tail": (None, None),  
    "DataFrame.checkpoint": ("DataFrame", "_dataframe_checkpoint"),
    "DataFrame.repartition": ("DataFrame", "_dataframe_repartition"), 
    "DataFrame.coalesce": ("DataFrame", "_dataframe_coalesce"),
    "DataFrame.withColumn": ("DataFrame", None),
    # DataFrameWriter    
    "DataFrameWriter.mode":("DataFrameWriter", None),
    "DataFrameWriter.format":("DataFrameWriter", None),
    "DataFrameWriter.option":("DataFrameWriter", None),
    "DataFrameWriter.partitionBy":("DataFrameWriter", None),
    "DataFrameWriter.save":(None, "_dataframewriter_save"),
    # str
    "str":("str","_callback_str"),
    "str.replace":("str", "str_replace"),
    "str.lower":("str", "_lower"),
    "str.join":("str",None),
    "str.split":("list",None),
    # list
    "list.append":(None, None),
    # pyspark.sql.functions
    "pyspark.sql.functions.col":("pyspark.sql.column.Column",None),
    "pyspark.sql.functions.lit":("pyspark.sql.column.Column",None),
    # print
    "print":(None, "_print")
}