from dataclasses import dataclass
from pathlib import Path
from analyzer.analyzer_config import CONST_CONFIG_RULES_INDEXED, CONST_CONFIG_RULES_KILL_JOB, CONST_CONFIG_RULES_PRE_DEPLOY
from collections import namedtuple

@dataclass
class FileAnalysisResult:
    ruta: str
    archivo: str = ""
    sufijo: str = ""
    distinct_number: int = 0
    collect_number: int = 0	
    nested_query_number: int = 0
    with_column_number: int = 0
    topandas_number: int = 0	
    select_all_number: int = 0
    spark_stop_number: int = 0	
    remove_files_number: int = 0		
    print_number: int = 0		
    show_number: int = 0			
    display_number: int = 0			
    logger_number: int = 0			
    dataframewriter_save_number: int = 0			
    dataframereader_load_number: int = 0			
    reasignacion_df_number: int = 0
    dataflow_version_number: int = 0
    dataframe_rdd_number: int = 0
    dataframe_coalesce_mult_partitions_number: int = 0
    dataframe_count_number: int = 0
    dataframe_checkpoint_number: int = 0
    dataframe_repartition_number: int = 0
    print_dataframe_head_number: int = 0
    print_dataframe_collect_number: int = 0
    print_dataframe_first_number: int = 0
    print_dataframe_tail_number: int = 0
    arquetype_version_number: int = 0
    nom_product_owner: str = ""
    nom_proveedor: str = ""
    nom_desarrollador: str = ""
    fch_pase: str = ""

    def __post_init__(self):
        if self.ruta is not None:
            self.archivo = Path(self.ruta).name
            self.sufijo = Path(self.ruta).suffix

    

    
@dataclass
class RuleAnalysisResult:    
    id_rule: str
    nom_rule: str = ""
    nom_criticidad: str = ""
    nom_categoria: str = ""   
    num_observaciones: int = 0

    def __post_init__(self):
        if self.nom_rule is not None:
            try:
                rule_config = CONST_CONFIG_RULES_INDEXED.get(self.id_rule)
                self.nom_criticidad = rule_config.nom_criticidad
                self.nom_categoria = rule_config.nom_categoria                
            except Exception as ex:
                pass

@dataclass
class FileRuleAnalysisResult:
    if_file: str    
    id_rule: str    
    num_observaciones: int = 0

    def add_obs(self, num_obs):
        self.num_observaciones = self.num_observaciones + num_obs
    
@dataclass
class RepoRuleAnalysisResult:
    id_rule:str
    num_observaciones: int = 0

    def add_obs(self, num_obs):
        self.num_observaciones = self.num_observaciones + num_obs

@dataclass
class RepoRuleAnalysisResponse:
    id_rule: str
    valor_actual: int
    nom_categoria: str=""
    nom_regla: str=""
    resultado: str=""
    umbral: int = None    

    def __post_init__(self):
        rule_config = CONST_CONFIG_RULES_INDEXED.get(self.id_rule)
        if not rule_config:
            raise Exception(f"No existe el id de la regla {self.id_rule}")
                
        self.nom_categoria = rule_config.nom_categoria
        self.nom_regla = rule_config.nom_regla
        self.umbral = rule_config.umbral
        self.resultado = self.calc_resultado(self.id_rule, self.umbral, self.valor_actual)
    
    def calc_resultado(self, id_rule, umbral, valor_actual):
        if valor_actual == 0:
            return "OK"
        
        # Si llega hasta aqui es porque error_count > 0
        # el or es para los casos donde umbral es mayor a 0
        if umbral == 0 or valor_actual > umbral:
            if id_rule in CONST_CONFIG_RULES_PRE_DEPLOY:
                return "FAILED (PILOTO PRE-DEPLOY)"
            elif id_rule in CONST_CONFIG_RULES_KILL_JOB:
                return "FAILED (KILL JOB)"
            else:
                return "FAILED"
        
        pct_cumplimiento = round((valor_actual/umbral)*100,2)
        # Estos casos son para cuando el umbral es mayor a 0 pero el error count es menor o igual        
        if pct_cumplimiento <= 75.00:
            return "INFO"

        if pct_cumplimiento > 75.00 and valor_actual <= umbral:
            return "WARNING"
        
        return "NO DEFINIDO"
    
    def as_result_tuple(self):
        return (self.nom_categoria, self.nom_regla, self.resultado, self.umbral, self.valor_actual)




    




    

