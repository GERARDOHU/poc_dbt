import analyzer.analyzer_constants as constants
from analyzer.analyzer_config import CONST_CONFIG_ANALYZER_RESULT_CSV
from analyzer.analyzer_structure import RuleAnalysisResult, FileRuleAnalysisResult, FileAnalysisResult
import re

class AnalyzerCoreSQL:
    def __init__(self):
        self.filepath = None
        self.content = None
        self.rules_analysis = []
        self.file_rules_analysis = {}
        self.file_analysis = None

    def get_contents(self, filepath):
        if self.content:
            return self.content
        else:
            with open(filepath, "r", encoding="utf8") as file:
                return file.read()
            
    def build_file_rules_analysis(self, rules_analysis):
        file_rules = {}

        obs: RuleAnalysisResult
        for obs in rules_analysis:
            file_rule_analysis = file_rules.get(obs.nom_rule)
            if file_rule_analysis:
                file_rule_analysis.add_rule_analysis(obs)
            else:
                file_rules[obs.nom_rule] = FileRuleAnalysisResult(obs.nom_rule, obs.num_observaciones)
        
        return file_rules
    
    def build_file_record(self, file_analysis_result:FileAnalysisResult):
        record = []        
        for col_config in CONST_CONFIG_ANALYZER_RESULT_CSV:
            try:
                nom_col, nom_header = col_config
                value = getattr(file_analysis_result, nom_col)
                record.append(value)
            except AttributeError as ex:
                raise Exception(f"No se ha encontrado el campo {nom_col} en FileAnalysisResult")
            
        return record
    
    def get_num_obs_from_file_rule(self, rule, file_rules_analysis):
        file_rule_analysis = file_rules_analysis.get(rule)
        if file_rule_analysis is None:
            return 0
        else:
            return file_rule_analysis.num_observaciones
        

    def build_file_analysis(self, file_rules_analysis):
        
        file_analysis = FileAnalysisResult(ruta=self.filepath,
                                            nested_query_number = self.get_num_obs_from_file_rule(constants.CONST_RULE_NESTED_QUERY, file_rules_analysis),
                                            select_all_number=self.get_num_obs_from_file_rule(constants.CONST_RULE_SELECT_ALL, file_rules_analysis)
                                           )
        return file_analysis

    
    def analyze(self, filepath):
        self.filepath = filepath

        contents = self.get_contents(filepath)
        self.add_obs(self.analyze_nested_query(contents))
        self.add_obs(self.analyze_select_all(contents))
        self.file_rules_analysis = self.build_file_rules_analysis(self.rules_analysis)
        self.file_analysis = self.build_file_analysis(self.file_rules_analysis)   

        return (self.file_analysis, self.rules_analysis)


    def analyze_nested_query(self, contents):
        contents = contents.lower()
        count = len(re.findall(
                    r"from\s+\(\s+select|"
                    r"from\s+\(select|"
                    r"from\(\s+select|"
                    r"from\(select|"
                    r"in\s+\(select|"
                    r"in\(select|"
                    r"in\(\s+select|"
                    r"join\s+\(select|"
                    r"join\(select|"
                    r"join\(\s+select|"
                    r"\.join\(\s+\.select|"
                    r"\.join\s+\(\.select|"
                    r"\.join\(\.select",
                    contents))

        if count > 0:
            result = RuleAnalysisResult(constants.CONST_RULE_KEY_NESTED_QUERY, num_observaciones=count)
            return result
            
    def analyze_select_all(self, contents):
        contents = contents.lower()
        count = len(re.findall(r"select\s+\*\s+from", contents))

        if count > 0:
            result = RuleAnalysisResult(constants.CONST_RULE_KEY_SELECT_ALL, num_observaciones=count)
            return result
        
    def add_obs(self, obs):
        if obs:
            self.rules_analysis.append(obs)        


