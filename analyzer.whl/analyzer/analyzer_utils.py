import uuid
from analyzer.analyzer_structure import RuleAnalysisResult, FileRuleAnalysisResult, RepoRuleAnalysisResult, RepoRuleAnalysisResponse

class FileAnalysisContainer:
    def __init__(self, filepath):
        self.id_file =  FileAnalysisContainer.gen_id_file(filepath) 
        self.filepath = filepath      
        self.rule_analysis_collection = []
        self.file_rule_analysis_collection = {}

    @staticmethod
    def gen_id_file(filepath):
        return uuid.uuid5(uuid.NAMESPACE_DNS, filepath)

    def add_rule_analysis(self, analysis):
        if isinstance(analysis, list):
            self.add_rule_analysis_list(analysis)
        else:
            self.add_rule_analysis_element(analysis)


    def add_rule_analysis_element(self, element: RuleAnalysisResult):
        if element.num_observaciones == 0:
            return
            
        if element.id_rule not in self.file_rule_analysis_collection:
            self.file_rule_analysis_collection[element.id_rule] = FileRuleAnalysisResult(self.id_file, element.id_rule, num_observaciones=element.num_observaciones)
        else:
            file_analysis_res = self.file_rule_analysis_collection.get(element.id_rule)
            file_analysis_res.add_obs(element.num_observaciones)        
        
        self.rule_analysis_collection.append(element)

    def add_rule_analysis_list(self, elements):
        element: RuleAnalysisResult
        for element in elements:
            self.add_rule_analysis_element(element)

    def get_file_rule_analysis_collection(self):
        return self.file_rule_analysis_collection
    
class RepoAnalysisContainer:
    def __init__(self):
        self.file_rule_analysis_result_collection = []
        self.rules_obs_collection = {}

    def add_file_rule_analysis(self, element):
        if isinstance(element, list):
            self.add_file_rule_analysis_list(element)
        else:
            self.add_file_rule_analysis_element(element)

    def add_file_rule_analysis_element(self, element):
        if element.num_observaciones == 0:
            return
        
        if element.id_rule not in self.rules_obs_collection:
            self.rules_obs_collection[element.id_rule] = RepoRuleAnalysisResult(element.id_rule, num_observaciones=element.num_observaciones)
        else:
            repo_analysis_res = self.rules_obs_collection.get(element.id_rule)
            repo_analysis_res.add_obs(element.num_observaciones)        
        
        self.file_rule_analysis_result_collection.append(element)
        

    def add_file_rule_analysis_list(self, elements):
        element: FileRuleAnalysisResult
        for element in elements:
            self.add_file_rule_analysis_element(element)

    def add_from_file_analysis_container_list(self, file_analysis_container_list):
        for file_analysis_container in file_analysis_container_list:
            self.add_file_rule_analysis(list(file_analysis_container.get_file_rule_analysis_collection().values()))

    def gen_responses(self):
        records = []

        repo_rule: RepoRuleAnalysisResult
        for repo_rule in self.rules_obs_collection.values():
            response = RepoRuleAnalysisResponse(id_rule=repo_rule.id_rule, valor_actual=repo_rule.num_observaciones).as_result_tuple()
            records.append(response)

        return records

    