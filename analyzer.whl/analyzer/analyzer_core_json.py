import json
from analyzer.analyzer_structure import FileAnalysisResult, RuleAnalysisResult
from analyzer.analyzer_config import CONST_CONFIG_ANALYZER_RESULT_CSV
import analyzer.analyzer_constants as constants
from pathlib import Path


class DatabricksJSON:
    def __init__(self, filepath):
        self.filepath = filepath        
        self.file_analysis = FileAnalysisResult(ruta=filepath) 
        self.rules_analysis = []

    def get_file_analysis_result(self):
        return self.file_analysis

    def analyze(self, contents):
        json_contents = json.loads(contents)
        self.analyze_creacion_databricks_jobs_workflow(json_contents)

        # se retorna el resultado del analisis
        return (self.file_analysis, self.rules_analysis)
    
    def analyze_creacion_databricks_jobs_workflow(self, json_contents):
        jobs_workflow = json_contents.get("creacion_databricks_jobs_workflow")
        for job in jobs_workflow:
            tasks = job.get("tasks")
            self.analyze_job_workflow_tasks(tasks)

    def analyze_job_workflow_tasks(self, tasks):
        for task in tasks:
            self.analyze_job_workflow_task(task)
    
    def analyze_job_workflow_task(self, task):
        libraries = task.get("libraries", [])
        self.analyze_task_libraries(libraries)

    def analyze_task_libraries(self, task_libraries):
        
        for library_item in task_libraries:
            value: str        
            for key, value in library_item.items():
                # la siguiente condicion identifica si es un dataflow
                if key.lower() == "jar" and "dataflow-engine-" in value:
                    self.eval_dataflow_version(value)
                elif key.lower() == "whl" and "pyspark_archetype_project-" in value:
                    self.eval_arquetype_version(value)
                else:
                    continue


    def add_rule_obs(self, rule_analysis):
        self.rules_analysis.append(rule_analysis)

    def add_arquetype_version_obs(self, num_obs=1):
        # Acumular observaciones en el fichero global
        file_analysis = self.get_file_analysis_result()
        file_analysis.arquetype_version_number = file_analysis.arquetype_version_number + num_obs

        # set
        rule_analysis = RuleAnalysisResult(
            id_rule=constants.CONST_RULE_KEY_ARQUETYPE_VERSION,
            num_observaciones=num_obs
        )

        self.add_rule_obs(rule_analysis)

    def eval_dataflow_version(self, dataflow_dependency_path):
        if not dataflow_dependency_path.endswith(r"dataflow-engine-1.4.2{snapshot}.jar"):
            self.add_dataflow_version_obs(num_obs=1)

    def eval_arquetype_version(self, arquetype_dependency_path):
        if not arquetype_dependency_path.endswith(r"pyspark_archetype_project-1.1.0-py3-none-any.whl"):
            self.add_arquetype_version_obs(num_obs=1)

    def add_dataflow_version_obs(self, num_obs):
        # set file obs
        file_analysis = self.get_file_analysis_result()
        file_analysis.dataflow_version_number = file_analysis.dataflow_version_number + num_obs

        # set 
        rule_analysis = RuleAnalysisResult(            
            id_rule=constants.CONST_RULE_KEY_DATAFLOW_VERSION,
            nom_criticidad=constants.CONST_CRITICIDAD_ALTA,
            nom_categoria=constants.CONST_CATEGORIA_OBSOLESCENCIA,
            num_observaciones=num_obs
        )

        self.add_rule_obs(rule_analysis)

class AnalyzerCoreJSON:
    def __init__(self, filepath):
        self.filepath = filepath
        self.filename = Path(filepath).name
        self.suffix = Path(filepath).suffix
        self.contents = self.get_file_contents(filepath)

    def get_file_contents(self, filepath):
        with open(filepath, "r", encoding="utf8") as file:
            return file.read()        
    
    def get_filename(self):
        return self.filename

    def get_filepath(self):
        return self.filepath
    
    def build_file_record(self, file_analysis_result:FileAnalysisResult):
        record = []        
        for col_config in CONST_CONFIG_ANALYZER_RESULT_CSV:
            try:
                nom_col, nom_header = col_config
                value = getattr(file_analysis_result, nom_col)
                record.append(value)
            except AttributeError as ex:
                raise Exception(f"No se ha encontrado el campo {nom_col} en FileAnalysisResult")
            
        return record


    def analyze(self):
        filename = self.get_filename()
        filepath = self.get_filepath()
        if filename.lower() == "databricks.json":
            db_json = DatabricksJSON(filepath)
            result = db_json.analyze(self.contents)            
            return result
        else:
            return None
        
        
        

    
    
    


