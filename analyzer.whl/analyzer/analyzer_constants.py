# rules key
CONST_RULE_KEY_DISTINCT = "dataframe_distinct"
CONST_RULE_KEY_COLLECT = "dataframe_collect"
CONST_RULE_KEY_NESTED_QUERY = "nested_query"
CONST_RULE_KEY_WITHCOLUMN = "dataframe_withcolumn"
CONST_RULE_KEY_TOPANDAS = "dataframe_topandas"
CONST_RULE_KEY_SELECT_ALL = "select_all"
CONST_RULE_KEY_SPARK_STOP = "spark_stop"
CONST_RULE_KEY_REMOVE_FILES = "remove_files"
CONST_RULE_KEY_PRINT = "print"
CONST_RULE_KEY_SHOW = "dataframe_show"
CONST_RULE_KEY_DISPLAY = "dataframe_display"
CONST_RULE_KEY_LOGGER = "logger"
CONST_RULE_KEY_HOOK_TEAMS_MSG = "hook_teams_msg"
CONST_RULE_KEY_DATAFRAMEWRITER_SAVE = "dataframewriter_save"
CONST_RULE_KEY_DATAFRAMEREADER_LOAD = "dataframereader_load"
CONST_RULE_KEY_DATAFRAME_REASIGNACION = "dataframe_reasignacion"
CONST_RULE_KEY_DATAFLOW_VERSION = "dataflow_version"
CONST_RULE_KEY_DATAFRAME_RDD = "dataframe_rdd"
CONST_RULE_KEY_DATAFRAME_COALESCE_MULTIPLE_PARTITIONS = "dataframe_coalesce_mult_part"
CONST_RULE_KEY_DATAFRAME_COUNT = "dataframe_count"
CONST_RULE_KEY_DATAFRAME_CHECKPOINT = "dataframe_checkpoint"
CONST_RULE_KEY_DATAFRAME_REPARTITION = "dataframe_repartition"
CONST_RULE_KEY_PRINT_DATAFRAME_HEAD = "print_dataframe_head"
CONST_RULE_KEY_PRINT_DATAFRAME_COLLECT = "print_dataframe_collect"
CONST_RULE_KEY_PRINT_DATAFRAME_FIRST = "print_dataframe_first"
CONST_RULE_KEY_PRINT_DATAFRAME_TAIL = "print_dataframe_tail"
CONST_RULE_KEY_ARQUETYPE_VERSION = "arquetype_version"

# Rules
CONST_RULE_DISTINCT = "distinct"
CONST_RULE_COLLECT = "DataFrame.collect"
CONST_RULE_NESTED_QUERY = "Query Anidada"
CONST_RULE_WITHCOLUMN = "DataFrame.withColumn"
CONST_RULE_TOPANDAS = "DataFrame.toPandas"
CONST_RULE_SELECT_ALL = "select all"
CONST_RULE_SPARK_STOP = "spark.stop"
CONST_RULE_REMOVE_FILES = "remove files"
CONST_RULE_PRINT = "print"
CONST_RULE_SHOW = "show"
CONST_RULE_DISPLAY = "display"
CONST_RULE_LOGGER = "logger (info/debug/warning)"
CONST_RULE_HOOK_TEAMS_MSG = "hook teams msg"
CONST_RULE_DATAFRAMEWRITER_SAVE = "dataframewriter save"
CONST_RULE_DATAFRAMEREADER_LOAD = "dataframereader load"
CONST_RULE_REASIGNACION_DF = "reasignacion de dataframe"
CONST_RULE_DATAFLOW_VERSION = "dataflow version"
CONST_RULE_DATAFRAME_RDD = "DataFrame.rdd"
CONST_RULE_DATAFRAME_COALESCE_MULTIPLE_PARTITIONS = "DataFrame.coalesce mult part"
CONST_RULE_DATAFRAME_COUNT = "DataFrame.count"
CONST_RULE_DATAFRAME_CHECKPOINT = "DataFrame.checkpoint"
CONST_RULE_DATAFRAME_REPARTITION = "DataFrame.repartition"
CONST_RULE_PRINT_DATAFRAME_HEAD = "print DataFrame.head"
CONST_RULE_PRINT_DATAFRAME_COLLECT = "print DataFrame.collect"
CONST_RULE_PRINT_DATAFRAME_FIRST = "print DataFrame.first"
CONST_RULE_PRINT_DATAFRAME_TAIL = "print DataFrame.tail"
CONST_RULE_ARQUETYPE_VERSION = "arquetype version"

# Tokens de exclusion
CONST_TOKEN_EXCLUSION_DATAFRAME_COLLECT= "DataFrame.collect"
CONST_TOKEN_EXCLUSION_DATAFRAME_READER_LOAD = "DataFrameReader.load"
CONST_TOKEN_EXCLUSION_DATAFRAME_WRITER_SAVE = "DataFrameWriter.save"
CONST_TOKEN_EXCLUSION_DATAFRAME_REASIGNACION = "reasignacion_df"
CONST_TOKEN_EXCLUSION_DATAFRAME_DISTINCT = "DataFrame.distinct"
CONST_TOKEN_EXCLUSION_DATAFRAME_TO_PANDAS = "DataFrame.toPandas"
CONST_TOKEN_EXCLUSION_DATAFRAME_COALESCE_MULT_PART = "DataFrame.coalesce_mult_part"
CONST_TOKEN_EXCLUSION_DATAFRAME_REPARTITION = "DataFrame.repartition"
CONST_TOKEN_EXCLUSION_DATAFRAME_CHECKPOINT = "DataFrame.checkpoint"


# Token de exclusion actualmente para global
CONST_TOKEN_EXCLUSION_PRINT = "print"
CONST_TOKEN_EXCLUSION_LOGGER = "logger"
CONST_TOKEN_EXCLUSION_SELECT_ALL = "select_all"
CONST_TOKEN_EXCLUSION_DATAFRAME_WITHCOLUMN = "DataFrame.withColumn"
CONST_TOKEN_EXCLUSION_NESTED_QUERY = "nested_query"

# Criticidades
CONST_CRITICIDAD_ALTA = "ALTA"
CONST_CRITICIDAD_MEDIA = "MEDIA"
CONST_CRITICIDAD_BAJA = "BAJA"

# Categoria de reglas
CONST_CATEGORIA_OPTIMIZACION = "OPTIMIZACION"
CONST_CATEGORIA_CALIDAD_CODIGO = "CALIDAD DE CODIGO"
CONST_CATEGORIA_SEGURIDAD = "SEGURIDAD"
CONST_CATEGORIA_GOBIERNO = "GOBIERNO"
CONST_CATEGORIA_OBSOLESCENCIA = "OBSOLESCENCIA"

# Constante para el maximo de particiones definido para la funcion coalesce
CONST_COALESCE_MAX_NUM_PARTITIONS = 1

# Constantes de Tablas
CONST_CATALOGO = 'PRM_CATALOGO'
CONST_ESQUEMA  = 'PRM_ESQUEMA'
CONST_TABLA_SRC_PREFIX = 'CONST_SRC_'

# Constante para validar vistas temporales locales
CONST_VISTA_TEMP = 'tmp_v_'

#constante para validar el prefijo de un dataframe
CONST_DATAFRAME = 'df_' 

