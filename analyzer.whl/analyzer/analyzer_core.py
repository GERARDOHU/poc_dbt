import ast
import sys
from enum import Enum
from collections import defaultdict
import copy
from dataclasses import dataclass, field
import re
import analyzer.analyzer_constants as constants
from typing import List
from analyzer.analyzer_config import CONST_CONFIG_RULES_TOKEN_EXCLUSION_INDEXED, CONST_CONFIG_RULES_TOKEN_EXCLUSION_GLOBAL_INDEXED

CONST_TEXT_EXCLUDE_ANALYZER = "# EXCLUDE_ANALYZER:"
CONST_TEXT_EXCLUDE_ANALYZER_GLOBAL = "# EXCLUDE_ANALYZER_GLOBAL:"

# esto es item: token de exclusion, value: key de la regla
"""
CONST_EXCLUDE_ANALYZER_GLOBAL_TOKENS = {
    "print":"print",
    "logger":"logger (info/debug/warning)",
    "select_all":"select all",
    "DataFrame.withColumn":"withColumn",
    "nested_query":"Query Anidada"
}
"""

class ExcludeAnalyzerToken(Enum):
    DATAFRAME_READER_LOAD = ("DataFrameReader.load", "dataframereader_load")
    DATAFRAME_WRITER_SAVE = ("DataFrameWriter.save", "dataframewriter_save")
    DATAFRAME_REASIGNACION = ("reasignacion_df", "reasignacion_df")
    DATAFRAME_DISTINCT = ("DataFrame.distinct", "dataframe_distinct")        
    DATAFRAME_COLLECT = ("DataFrame.collect", "dataframe_collect")
    # DATAFRAME_WITH_COLUMN = ("DataFrame.withColumn", "dataframe_withcolumn")
    DATAFRAME_TO_PANDAS = ("DataFrame.toPandas", "dataframe_topandas")    
    # DATAFRAME_SHOW = ("DataFrame.show", "dataframe_show")

    @classmethod
    def has_exclude_token(cls, token):
        for exclude_token, rule_key in cls._value2member_map_:
            if token == exclude_token:
                return True
            
        return False        

    @classmethod
    def get_rule_key(cls, token):
        for exclude_token, rule_key in cls._value2member_map_:
            if token == exclude_token:
                return rule_key
        
        return False

class DBUtilsHelper:
    def __init__(self):
        self._widgets = {}

    @property
    def widgets(self):        
        return self._widgets
    
    def text(self, param, val):
        self._widgets[param] = val

    def get(self, key):
        return self._widgets.get(key)

class ReturnType(Enum):
    CLASS = "class"
    LITERAL = "literal"
    UNDEFINED = "NO DEFINIDO"
    DATA_FRAME = "DataFrame"
    DATA_FRAME_READER = "DataFrameReader"
    DBUTILS_WIDGETS = "dbutils.widgets"
    SPARK_SESSION = "SparkSession"
    STRING = "str"
    NUMERIC = "numeric"
    LIST = "list"

class NameHelper:
    #Nombre: (Tipo de dato del nombre, callback)
    CONFIG = {
        "dbutils": ("RemoteDbUtils", None),
        "spark": ("SparkSession", None)
    }

class AttributeHelper:
    CONFIG = {        
        "DefaultValueOnlyWidgetUtils.text":None,
        "DefaultValueOnlyWidgetUtils.get":"str",
        "RemoteDbUtils.widgets":"DefaultValueOnlyWidgetUtils", 
        "dbutils.widgets.get":"str",
        # SparkSession
        "SparkSession.read":"DataFrameReader",
        "SparkSession.sql":"DataFrame",
        "SparkSession.createDataFrame":"DataFrame",
        "SparkSession.table":"DataFrame",
        # DataFrameReader
        "DataFrameReader.format": "DataFrameReader",
        "DataFrameReader.load": "DataFrameReader",        
        "DataFrameReader.option": "DataFrameReader", 
        "DataFrameReader.table": "DataFrame",
        # DataFrame             
        "DataFrame.write":"DataFrameWriter",
        "DataFrame.filter":"DataFrame",
        "DataFrame.join":"DataFrame",
        "DataFrame.count":"int",                    #AGREGUE
        "DataFrame.checkpoint":"DataFrame",         #AGREGUE
        "DataFrame.repartition":"DataFrame",        #AGREGUE
        "DataFrame.head":"list",                    #AGREGUE
        "DataFrame.collect":"list",                 #AGREGUE
        "DataFrame.first":None,                     #AGREGUE
        "DataFrame.tail":None,                      #AGREGUE  
        # DataFrameWriter
        "DataFrameWriter.mode":"DataFrameWriter",
        "DataFrameWriter.format":"DataFrameWriter",
        "DataFrameWriter.option":"DataFrameWriter",
        "DataFrameWriter.partitionBy":"DataFrameWriter",
        "DataFrameWriter.save":None,
        # str
        "str.replace":"str",
        "str.lower":"str",
        "str.join":"str",
        "str.split":"list"
    }

class CallHelper:
    # (Tipo de dato devuelvo, función a evaluar)
    CONFIG = {
        # StructType
        "StructType":("StructType", None),
        "StructField": ("StructField", None),
        # DataFrameReader
        "DataFrameReader.load":("DataFrame","_dataframereader_load"),
        "DataFrameReader.format":("DataFrameReader","_dataframereader_format"),
        "DataFrameReader.table":("DataFrame","_spark_session_table"),
        "DataFrameReader.option":("DataFrameReader", None),
        "DataFrameReader.csv":("DataFrame",None),
        "DataFrameReader.parquet":("DataFrame", None),
        # DefaultValueOnlyWidgetUtils
        "DefaultValueOnlyWidgetUtils.text":(None, "_dbutils_widgets_text"),
        "DefaultValueOnlyWidgetUtils.get":("str", "_dbutils_widgets_get"),
        # SparkSession
        "SparkSession.table":("DataFrame","_spark_session_table"),
        "SparkSession.sql":("DataFrame","_spark_session_sql"),
        "SparkSession.createDataFrame":("DataFrame",None),
        # DataFrame
        "DataFrame.first":("Row",None), 
        "DataFrame.filter":("DataFrame",None),
        "DataFrame.count":("int","_dataframe_count"),  
        "DataFrame.select":("DataFrame",None),
        "DataFrame.alias":("DataFrame",None),
        "DataFrame.join":("DataFrame",None),
        "DataFrame.take":("list",None),        
        "DataFrame.toPandas":("pandas.DataFrame","_dataframe_topandas"),
        "DataFrame.collect":("list","_dataframe_collect"),
        "DataFrame.distinct":("DataFrame","_dataframe_distinct"),
        "DataFrame.persist":("DataFrame", None),   
        "DataFrame.show":("DataFrame", None),   
        "DataFrame.union":("DataFrame", None),   
        "DataFrame.unionAll":("DataFrame", None),
        "DataFrame.createOrReplaceTempView":(None, None),
        "DataFrame.drop_duplicates":("DataFrame", None),                
        "DataFrame.groupBy":("GroupedData",None),        
        "DataFrame.groupby":("GroupedData",None),        
        "DataFrame.drop":("DataFrame",None),
        "DataFrame.cache":("DataFrame",None),
        "DataFrame.where":("DataFrame",None),
        "GroupedData.agg":("DataFrame",None),
        "DataFrame.head":("list",None),     
        "DataFrame.tail": (None, None),  
        "DataFrame.checkpoint": ("DataFrame", "_dataframe_checkpoint"),
        "DataFrame.repartition": ("DataFrame", "_dataframe_repartition"), 
        "DataFrame.coalesce": ("DataFrame", "_dataframe_coalesce"),
        "DataFrame.withColumn": ("DataFrame", None),
        # DataFrameWriter    
        "DataFrameWriter.mode":("DataFrameWriter", None),
        "DataFrameWriter.format":("DataFrameWriter", None),
        "DataFrameWriter.option":("DataFrameWriter", None),
        "DataFrameWriter.partitionBy":("DataFrameWriter", None),
        "DataFrameWriter.save":(None, "_dataframewriter_save"),
		# str
        "str":("str","_callback_str"),
        "str.replace":("str", "str_replace"),
        "str.lower":("str", "_lower"),
        "str.join":("str",None),
        "str.split":("list",None),
        # list
        "list.append":(None, None),
        # pyspark.sql.functions
        "pyspark.sql.functions.col":("pyspark.sql.column.Column",None),
        "pyspark.sql.functions.lit":("pyspark.sql.column.Column",None),
        # print
        "print":(None, "_print")
    }

class UndefinedCallHelper:
    CONFIG = {
        "UNDEFINED.distinct":("UNDEFINED", "_dataframe_distinct"),
        "UNDEFINED.collect":("UNDEFINED", "_dataframe_collect"),
        "UNDEFINED.toPandas":("UNDEFINED", "_dataframe_topandas")
    }



@dataclass
class Response:
    context: "any" = None 
    # node: str = None
    lineno: int = 0
    trace: list = field(default_factory=list)
    # issues: "defaultdict" = field(default_factory=lambda: defaultdict(list))
    # errors: list = field(default_factory=list)

    def add_trace(self, prev_trace:list, response):
        self.trace = prev_trace.append(response)
    
@dataclass
class FunctionDefResponse(Response):    
    func_name:str = None
    return_type:str = None
    return_value: str = None 
    returns: str = None   

@dataclass
class ClassDefResponse(Response):
    class_name: str = None    

@dataclass
class AssignResponse(Response):           
    assigns: "defaultdict" = field(default_factory=lambda: defaultdict(tuple))        
    target_id: str = None        
    value: str = None        
    value_source: any = None
    value_type: str = None  
              
    def __post_init__(self):      
        self.eval_value_source(self.value_source)  

        assign = self.context.get_target(self.target_id)

        assign_hist = []
        nu_current = self

        if assign is not None:
            current, assign_hist = assign   
            self.eval_reasignacion_df(nu_current=nu_current, assign_hist=assign_hist)


        nu_assign_hist = assign_hist + [nu_current]

        # assign_hist.append(nu_current)
        self.context.targets[self.target_id] = (nu_current, nu_assign_hist)                

    def eval_value_source(self, value_source):
        value_type, value = value_source
        
        if isinstance(value, BinOpResponse):
            self.value = value.value
            self.value_type = value.value_type
        elif isinstance(value, SubscriptResponse):
            self.value = value.result_value            
            self.value_type = value.result_type
        else:
            self.value = value
            self.value_type = value_type
            
    
    def eval_reasignacion_df(self, nu_current, assign_hist):
        for assign in assign_hist:
            if assign.value_type == "DataFrame":
                self.context.collector.add_obs(constants.CONST_RULE_KEY_DATAFRAME_REASIGNACION, self.lineno, f"Ya se ha declarado previamente el dataframe {nu_current.target_id}")                
                break

@dataclass
class CallResponse(Response):    
    # object_name: str = None
    attr_value: "any"=None
    attr_value_type: str = None
    attr_value_name: str = None
    func_name: str = None
    return_type: str = None
    return_val: str = None
    args: "any" = None
    args_name: "any" = None
    normalized_args: dict = field(default_factory=dict)    
    keywords: dict = field(default_factory=dict)
    dbutils: dict = field(default_factory=dict)
    func_name_list: List[str] = field(default_factory=list)

    def __post_init__(self):        
        call_name = self.func_name if self.attr_value_type is None else f"{self.attr_value_type}.{self.func_name}"

        if self.attr_value_name == "self":
            self.fill_from_func_def_in_class(self.attr_value_name, self.func_name)
        
        elif self.context.find_func_defs(self.func_name):
            self.fill_from_func_defs(self.func_name)        

        elif self.attr_value_type == "UNDEFINED":
            self.process_from_undefined_attr_type(self.func_name)        

        elif self.context.get_import(call_name):
            key_call_name = self.context.get_import(call_name)            
            self.process_imported_call(key_call_name)

        elif call_name in CallHelper.CONFIG:
            self.fill_from_standard_func_defs(self.attr_value_type, self.func_name)

        else:
            self.context.collector.add_error(self.lineno, f"No se ha podido encontrar la definición para {call_name}")
            
        
    def fill_from_func_def_in_class(self, attr_value_name:str, func_name:str):
        if attr_value_name == "self":
            ctx_class = self.context.get_container_class_context()
            if ctx_class is None:
                return
            
            if func_name in ctx_class.func_defs:
                func_def_resp = ctx_class.func_defs[func_name]
                self.return_type = func_def_resp.return_type
                return func_def_resp
            
    def fill_from_func_defs(self, func_name:str):        
        func_def = self.context.find_func_defs(func_name)
        if func_def is not None:
            self.return_type = func_def.return_type
            return func_def    

    def process_imported_call(self, call_key):
        if not (call_key in CallHelper.CONFIG):
            self.context.collector.add_error(self.lineno, f"configuración no encontrada para el import {call_key}")
            return
        
        return_type, func_callback = CallHelper.CONFIG.get(call_key)
        if func_callback is not None:
            getattr(self, func_callback)()        
            self.return_type = return_type                    
        
    def fill_from_standard_func_defs(self, attr_value_type:str, func_name:str):
        config = self.get_standar_func_conf(attr_value_type, self.func_name)
        if config is None:
            self.context.collector.add_error(self.lineno, f"No se ha encontrado la configuracion para {attr_value_type}.{func_name}")
            return
        # raise Exception(f"funcion no soportada {self.object_name}.{self.func_name}")
        
        if config is not None:
            return_type, func_callback = config
            if func_callback is not None:
                getattr(self, func_callback)()        
            self.return_type = return_type        

    def str_replace(self):
        oldval = ""
        newval = ""

        if self.args and len(self.args) == 2:
            oldval = str(self.args[0])
            newval = str(self.args[1])

        value = "" if self.attr_value is None else self.attr_value
        new_string = value.replace(oldval, newval)
        self.return_val = new_string


    def process_from_undefined_attr_type(self, func_name:str):
        # Si ha entrado aqui es que el valor de retorno debe ser igual "UNDEFINED"
        # ya que no se puede determinar el objeto de la funcion que ha sido llamada
        self.return_type = "UNDEFINED"

        # Se busca las llamadas a la funcion
        call_name = f"UNDEFINED.{func_name}"
        if call_name in UndefinedCallHelper.CONFIG:
            config = UndefinedCallHelper.CONFIG[call_name]
            
            return_type, func_callback = config
            if func_callback is not None:
                getattr(self, func_callback)()        

            

    def get_func_def(self, func_name):        
        func_def = self.context.get_func_def(func_name)
        return func_def

    def get_standar_func_conf(self, object_name, func_name):
        qualname = func_name if object_name is None else f"{object_name}.{func_name}"
        config = CallHelper.CONFIG.get(qualname)
        return config            

    def _dataframereader_format(self):        
        self.normalized_args["source"] = self.args[0]

    def _dataframereader_load(self):                        
        path = None
        source = None

        # Si hay args se busca el path dentro
        path_search = self._find_path_df_reader(self.args, self.trace)
        if path_search is None:
            self.context.collector.add_error(self.lineno, "_dataframereader_load no hay path que validar")
            return
        
        path, path_source_type = path_search
        source = self._find_source_df_reader(self.trace)
        if source is None:
            self.context.collector.add_error(self.lineno, "_dataframereader_load no hay source que validar")
            return
                  
        if "abfss://" in path and source == "delta":
            self.context.collector.add_obs("dataframereader_load", self.lineno, "No se puede leer una ruta abfss:// de una tabla delta")            

    def _find_source_df_reader(self, trace):
        if not trace:
            return
        
        for item in trace:                        
            if not (isinstance(item, CallResponse) and item.attr_value_type == ReturnType.DATA_FRAME_READER.value and item.func_name == "format"):
                continue
            else:
                source = item.normalized_args.get("source")
                return source

    def _find_path_df_reader(self, args, trace):
        if args:
            path = args[0]
            if path is None:
                self.context.collector.add_error(self.lineno, f"No se ha podido identificar el path en _dataframereader_load")
                return None
            else:
                return path, "args"
        else:
            value = self._find_option(trace=trace, key="path")
            if value is not None:
                return value, "option"

    def _find_option(self, trace, key):        
        if not trace:
            return
        
        for item in trace:
            if not (isinstance(item, CallResponse) and item.func_name =="option"):
                continue

            value = item.normalized_args.get(key)
            if value is not None:
                return value
            
            

                




    def _dataframe_distinct(self):
        self.context.collector.add_obs(constants.CONST_RULE_KEY_DISTINCT , self.lineno, "No está permitido DataFrame.distinct")

    def _dataframe_collect(self):
        self.context.collector.add_obs(constants.CONST_RULE_KEY_COLLECT, self.lineno, "No está permitido DataFrame.collect")
  
    def _dataframe_topandas(self):
        self.context.collector.add_obs(constants.CONST_RULE_KEY_TOPANDAS, self.lineno, "No está permitido DataFrame.toPandas")

    def _print(self):
        self._print_dataframe_collect()
        self._print_dataframe_head()
        self._print_dataframe_first()
        self._print_dataframe_tail()
        

    def filter_list_traces(self, name):     
        for traces in self.trace:
            if isinstance(traces, CallResponse):      
                names = traces.func_name
                value_types = traces.attr_value_type
                if names == name and value_types == 'DataFrame':
                    return True
        return False


    def _print_dataframe_collect(self):
        encontrado = self.filter_list_traces("collect")
        if encontrado:
            self.context.collector.add_obs(constants.CONST_RULE_KEY_PRINT_DATAFRAME_COLLECT, self.lineno, "se encontró un collect() dentro de un print")

    def _print_dataframe_head(self):
        encontrado = self.filter_list_traces("head")
        if encontrado:
            self.context.collector.add_obs(constants.CONST_RULE_KEY_PRINT_DATAFRAME_HEAD, self.lineno, "se encontró un head() dentro de un print")
            

    def _print_dataframe_first(self):
        encontrado = self.filter_list_traces("first")
        if encontrado:
            self.context.collector.add_obs(constants.CONST_RULE_KEY_PRINT_DATAFRAME_FIRST, self.lineno, "se encontró un first() dentro de un print")

    def _print_dataframe_tail(self):
        encontrado = self.filter_list_traces("tail")
        if encontrado:
            self.context.collector.add_obs(constants.CONST_RULE_KEY_PRINT_DATAFRAME_TAIL, self.lineno, "se encontró un tail() dentro de un print")

    def _dataframe_count(self):   
        self.context.collector.add_obs(constants.CONST_RULE_KEY_DATAFRAME_COUNT, self.lineno, "se encontró un count()") 

    def _dataframewriter_saveastable(self):   
        # self.context.collector.add_obs("dataframe_saveastable", self.lineno ,"se encontró un saveAsTable()") 
        pass

    def _dataframe_cache(self):   
        # self.context.collector.add_obs("dataframe_cache",self.lineno, "se encontró un cache()") 
        pass

    def _spark_session_table(self):
        if self.func_name=='table':
            self.eval_param_spark_table_formato()
            self.eval_param_spark_table_filter()

    def eval_param_spark_table_formato(self):
        try:
            parametros=[]
            widget_variables=[]
                        
            parametros = self.get_args_name()
            widget_variables = self.dbutils['widgets_get']
            
            if len(parametros) == 0:
                self.context.collector.add_error(self.lineno, "eval_param_spark_table_formato No tiene parametros self.args_name")
            elif len(parametros) == 3:
                first, second, third = parametros [:3]
                parm1 = (first in constants.CONST_CATALOGO and first in widget_variables)
                parm2 = (second.startswith(constants.CONST_ESQUEMA) and second not in [var[0] for var in widget_variables])
                parm3 = (third.startswith(constants.CONST_TABLA_SRC_PREFIX) and third not in [var[0] for var in widget_variables])
                
                if parm1 and parm2 and parm3: 
                    return 
                else:
                    error_message = []
                    if not parm1:                        
                        error_message.append(f"  - La Primera variable '{first}' está mal escrita. Debería ser {constants.CONST_CATALOGO} y debe ser de tipo widget")
                    if not parm2:     
                        error_message.append(f"  - Segunda variable '{second}' debe comenzar con {constants.CONST_ESQUEMA} y no debe ser tipo widget")
                    if not parm3: 
                        error_message.append(f"  - Tercer valor '{third}' debe comenzar con {constants.CONST_TABLA_SRC_PREFIX} y no debe ser tipo widget")

                    error_message_str = "\n".join(error_message)                                    
                    self.context.collector.add_obs("param_spark_table", self.lineno, f"- variables {repr(parametros)}\n{error_message_str}")                    
            else:
                self.context.collector.add_obs("param_spark_table",self.lineno,  f"tiene  {len(parametros)} variables {repr(parametros) }- debe tener 3")
        
        
        except Exception as e:             
             self.context.collector.add_error(self.lineno, f"Error eval_param_spark_table_formato: {str(e)}")

    def eval_param_spark_table_filter(self):  
        try: 
            valor_final = self.get_table_name_value()

            if any(valor_final.startswith(prefix) for prefix in constants.CONST_TABLE_STARTSWITH):
                self.context.collector.add_obs("param_spark_table_filter",self.lineno, f"La lectura de una tabla histórica o mensual spark.table({valor_final}) debe incluir un filtro.")                       

        except Exception as e:            
            self.context.collector.add_error(self.lineno, f"Error in eval_param_spark_table_filter: {e}")

    def get_args_name(self):  
        for item in self.args_name:
            if item is None or item == 'None':
                arg_names = []
            else:
                arg_names = item.split('.')
        return arg_names
    

    def get_table_name_value(self):
        try: 
            valor_final = ""
            if any(func['name'] in ['where', 'filter']  
                for func in self.func_name_list):
                return ""
            valor = self.args[0] 
            if valor is None: 
                return ""
                
            valor_final = valor.lower().split('.')[-1]
            return valor_final

        except Exception as e:
            print(f"Error en get_valor_argumento:{self.lineno} {str(e)}")
            return ""
 
    def _dataframe_checkpoint(self):   
        self.context.collector.add_obs(constants.CONST_RULE_KEY_DATAFRAME_CHECKPOINT, self.lineno ,"se encontró un checkpoint()") 

    def _dataframe_persist(self):   
        pass
        # self.context.collector.add_obs("dataframe_persist", self.lineno ,"se encontró un persist()") 

    def _dataframe_repartition(self):   
        self.context.collector.add_obs(constants.CONST_RULE_KEY_DATAFRAME_REPARTITION, self.lineno ,"se encontró un repartition()")

    def _dataframe_coalesce(self):  
        numPartitions = self.args[0]
        if numPartitions > constants.CONST_COALESCE_MAX_NUM_PARTITIONS:
            self.context.collector.add_obs(constants.CONST_RULE_KEY_DATAFRAME_COALESCE_MULTIPLE_PARTITIONS, self.lineno ,f"se encontró un coalesce({numPartitions})") 

    def _dataframe_join(self):   
        self.context.collector.add_obs("dataframe_join",  self.lineno, f"tiene 1 {self.func_name}")

    def _dbutils_widgets_text(self):
        keywords_from_args = {}
        # args to keyworkds
        for idx, elem in enumerate(self.args, start=0):
            if idx == 0:
                 keywords_from_args["name"] = elem
            if idx == 1:
                keywords_from_args["defaultValue"] = elem

        all_keywords = {**keywords_from_args, **self.keywords}
        name = all_keywords.get("name")
        default_val = all_keywords.get("defaultValue")
        self.dbutils["widgets"][name] = default_val

    def _dbutils_widgets_get(self):
        keywords_from_args = {}
        # args to keyworkds
        for idx, elem in enumerate(self.args, start=0):
            if idx == 0:
                 keywords_from_args["name"] = elem

        name = keywords_from_args["name"]
        self.return_val = self.dbutils["widgets"].get(name, None)
        self.return_type = ReturnType.STRING.value
    
    def _dataframewriter_save(self):        
        keywords = ["path", "format", "mode"]
        keywords_from_args = {}
        for idx, arg_item in enumerate(self.args, start=0):
            keyname = keywords[idx]
            keywords_from_args[keyname] = arg_item

        path = keywords_from_args.get("path")
        if path is None:
            self.context.collector.add_error(self.lineno, "No se ha podido identificar el parámetro [path] para DataFrameWriter.save")
        elif "abfss://" in path:            
            self.context.collector.add_obs(constants.CONST_RULE_KEY_DATAFRAMEWRITER_SAVE,self.lineno,"No se puede escribir en una ruta abfss://")

    def _spark_session_sql(self):
        keywords = ["sqlQuery"]        
        keywords_from_args = {}
        for idx, arg_item in enumerate(self.args, start=0):
            keyname = keywords[idx]
            keywords_from_args[keyname] = arg_item

        sqlQuery = keywords_from_args.get("sqlQuery")
        if sqlQuery is None:
            self.context.collector.add_error(self.lineno, "sqlQuery es None _spark_session_sql")
        else:
            query = self.__clean_query(sqlQuery)
            self.__find_distinct_in_query(query)


    def __find_distinct_in_query(self, query):
        if self.lineno == 502:
            pass

        query = query.lower()
        matches = re.findall(r'\s*select\s+distinct', query)
        for match in matches:        
            self.context.collector.add_obs(constants.CONST_RULE_KEY_DISTINCT, self.lineno, f"No está permitido select distinc dentro de SparkSession.sql")

    def __clean_query(self, query):
        query = query.replace("\n"," ")
        return query

    

    def _callback_str(self):
        obj = self.args[0]
        self.return_type = ReturnType.STRING.value
        self.return_val = str(obj)        

    def _lower(self):     
        if self.attr_value is not None:
            self.return_type = ReturnType.STRING.value
            self.return_val = self.attr_value.lower()
               

@dataclass
class AttributeResponse(Response):     
    value:"any" = None
    value_type:"any" = None
    value_name:"str" = None
    # object_name: str = None    
    attr: str = None    
    return_type: str = None
    return_val: "any" = None   


    def __post_init__(self):                   
        # Si no se encuentra en una asignacion previa buscamos en libreria estandar
        
        qual_attr_name = f"{self.value_type}.{self.attr}"
        if qual_attr_name in AttributeHelper.CONFIG: 
            qual_attr_name = f"{self.value_type}.{self.attr}"
            self.return_type = AttributeHelper.CONFIG.get(qual_attr_name)
            return
        
        
@dataclass
class NameResponse(Response):
    global_var_name: str = None
    var_name: str = None
    var_type: str = None
    var_value: str = None   

    def __post_init__(self):
        if self.var_name == "self":
            container_class = self.context.get_container_class_context()
            if container_class is None:
                return None
            self.var_type = container_class.key            
            return

        if self.var_name in NameHelper.CONFIG:
            var_type, callback = NameHelper.CONFIG.get(self.var_name)
            self.var_type = var_type
            return

        # Buscar en variables
        target = self.context.get_target(self.var_name)
        if target is not None:
            assign, hist = target
            if assign.value_type is None:
                self.var_type = "UNDEFINED"
                self.var_value = assign.value
            else:
                self.var_type = assign.value_type            
                self.var_value = assign.value
            return
        
        # Buscar en definiciones de funciones
        func_def = self.context.get_func_def(self.var_name)
        if func_def is not None:
            self.var_type = func_def.return_type
            return
        
        # Si no esta en ningun lado ponemos como undefined
        self.var_type = "UNDEFINED"
            

@dataclass
class SliceResponse(Response):
    lower: any=None    
    upper: any=None    
    step: any=None        

@dataclass
class SubscriptResponse(Response):    
    slice_source: any = None
    slice_lower: any = None
    slice_upper: any = None
    slice_step: any = None
    slice_index: any = None
    slice_key: any = None
    value_type: str = None
    value_source: any = None
    value: any = None
    result_value: any = None
    result_type: any = None

    def __post_init__(self):
       self.eval_slice(self.slice_source)
       self.eval_value(self.value_source)
       self.eval_result(self.slice_source) 

    def eval_slice(self, slice_source):
        if isinstance(slice_source, SliceResponse):
            self.slice_lower = slice_source.lower
            self.slice_upper = slice_source.upper
            self.slice_step = slice_source.step

    def eval_value(self, value_source):
        if isinstance(value_source, NameResponse):
            self.value_type = value_source.var_type
            self.value = value_source.var_value

    def eval_result(self, slice_source):
        if isinstance(slice_source, SliceResponse):
            if self.value_type == "str":
                self.result_type = self.value_type
                self.result_value = self.slice_str(self.value, self.slice_lower, self.slice_upper, self.slice_step)
            
    def slice_str(self, input_str, lower, upper, step):
        if input_str is None:
            return ""
        
        sliced_text = input_str[lower:upper:step]                    
        return sliced_text




            

@dataclass
class BinOpResponse(Response):
    left_source: any = None
    left_type: str = None
    left_value: any = None
    right_source: any = None
    right_type: str = None
    right_value: any = None
    op: any = None
    value: any=None
    value_type: str = None

    def __post_init__(self):
        self.eval_left_source(self.left_source)
        self.eval_right_source(self.right_source)
        self.eval_result(self.op, self.left_type, self.right_type)
        

    def eval_left_source(self, left_source):
        if isinstance(left_source, SubscriptResponse):
            self.left_type = left_source.result_type
            self.left_value = left_source.result_value

    def eval_right_source(self, right_source):
        if isinstance(right_source, SubscriptResponse):
            self.right_type = right_source.result_type
            self.right_value = right_source.result_value

    def eval_result(self, op, left_type, right_type):
        if isinstance(op, ast.Add):
            if left_type == "str" or right_type == "str":
                self.value_type = "str"
                if self.left_value is None or self.right_value is None:
                    self.context.collector.add_error(self.lineno, f"No se puede concatenar {str(self.left_value)} y {str(self.right_value)}")
                    return
                
                self.value = self.left_value + self.right_value

@dataclass
class ReturnResponse(Response):    
    value: any=None
    value_type: str = None
    value_source: any = None 

    def __post_init__(self):
        self.eval_value_source(self.value_source)

    def eval_value_source(self, value_source):
        if isinstance(value_source, NameResponse):
            self.value_type = value_source.var_type
        if isinstance(value_source,CallResponse):
            self.value_type = value_source.return_type   

        if isinstance(value_source, IfExpResponse):
            pass


@dataclass
class IfExpResponse(Response):
    body_source: any = None
    body_value: any = None
    body_value_type: any = None    
    orelse_source: any = None
    orelse_value: any = None
    orelse_value_type: any = None

    def __post_init__(self):
        self.eval_body_source(self.body_source)
        self.eval_orelse_source(self.orelse_source)

    def eval_body_source(self, body_source):
        if isinstance(body_source, NameResponse):
            self.body_value_type = body_source.var_type
            

    def eval_orelse_source(self, orelse_source):
        if isinstance(orelse_source, NameResponse):
            self.orelse_value_type = orelse_source.var_type

class CtxCollector:    

    def __init__(self, exclusiones=[]):                        
        self.errors = []
        self.obs = defaultdict(list)
        self.exclusiones = exclusiones
    
    def add_error(self, lineno, error_msg):        
        self.errors.append((lineno, error_msg))

    def add_obs(self, rule, lineno, obs_msg):                
        self.obs[rule].append((lineno, obs_msg))

    def exclude_all_obs(self):
        for exclusion in self.exclusiones:  
            self.exclude_tokens(exclusion.exclude_linenum, exclusion.exclusions)            
        return self.obs

    def exclude_tokens(self, exclusion_line, exclusion_token_list:list):
        for exclusion_token in exclusion_token_list:
            exclusion_rule = CONST_CONFIG_RULES_TOKEN_EXCLUSION_INDEXED.get(exclusion_token)
            self.exclude_obs(exclusion_line, exclusion_rule.id_regla)

    
    def exclude_obs(self, lineno, rule_key):
        if self.obs.get(rule_key) is None:
            return     

        unexcluded_lineno = lineno
        new_obs = []

        for obs_item in self.obs.get(rule_key):
            obs_lineno, obs_text = obs_item
            if unexcluded_lineno > 0 and obs_lineno > unexcluded_lineno:
                unexcluded_lineno = 0
                continue
            else:
                new_obs.append(obs_item)
        
        self.obs[rule_key] = new_obs        
    
    def get_handled_errors(self):
        return self.errors
    
class AttributeCollector:

    @staticmethod
    def collect_property_rdd(collector: CtxCollector, attribute_node: ast.Attribute):
        attr_name = attribute_node.attr
        if attr_name == "rdd":
            collector.add_obs(constants.CONST_RULE_KEY_DATAFRAME_RDD, attribute_node.lineno, "No esta permitido el uso de la propiedad rdd")

class BaseContext:
    def __init__(self, key=None, parent=None, collector=[]):
        self.collector = collector
        self.key = key  
        self.parent = parent
        self.targets = defaultdict(dict)
        self.func_defs = defaultdict(dict) 

    def get_func_def(self, func_def_name):
        func_def = self.func_defs.get(func_def_name)
        if func_def is not None:
            return func_def
        
        # Si no se encuentra buscamos en los padres
        if self.parent is not None:
            return self.parent.get_func_def(func_def_name)

    def get_target(self, target_id):
        target = self.targets.get(target_id)
        if target is not None:
            return target

        # Si no se encuentra, se busca en los padres
        if self.parent is not None:
            return self.parent.get_target(target_id)    
        
    def get_import(self, import_key):           
        if hasattr(self, "imports"):
            import_info = self.imports.get(import_key)
            if import_info is not None:
                return import_info
            
            if import_info is None and self.parent is not None:
                return self.parent.get_import(import_key)
        else:
            if self.parent is not None:
                return self.parent.get_import(import_key)
                    
            
    def get_root(self):
        if self.parent is None:
            return self
        
        # Si no es root
        parent = self.parent
        return parent.get_root()   
    
    def get_container_class_context(self):
        if isinstance(self.parent, ClassContext):
            return self.parent
        elif self.parent is not None:
            return self.parent.get_container_class_context()

    def find_func_defs(self, func_name:str):
        if not isinstance(self, ClassContext):
            if func_name in self.func_defs:
                return self.func_defs[func_name]
            elif self.parent is not None:
                return self.parent.find_func_defs(func_name)


class ModuleContext(BaseContext):
    def __init__(self, key=None, parent=None, collector=[]):
        super().__init__(key, parent, collector)
        self.imports = defaultdict(dict)
        self.class_defs = defaultdict(dict)

class ClassContext(BaseContext):
    def __init__(self, key=None, parent=None, collector=[]):
        super().__init__(key, parent, collector)

class FunctionContext(BaseContext):
    def __init__(self, key=None, parent=None, collector=[]):
        super().__init__(key, parent, collector)
        self.args = defaultdict(dict)  
        self.returns = defaultdict(dict)  
     
class Resolver:    
    def __init__(self):        
        self.func_def = defaultdict(FunctionDefResponse)         
        self.dbutils = {"widgets":{}}# DBUtilsHelper()
        self.current_stmt = None  
        self.call_stack = []  
        self.exclusiones = None
        self.context = None 
        self.func_name_list = []
   
    def get_func_name(self, func_node):
        if hasattr(func_node, 'attr'):
            return func_node.attr
        
        if hasattr(func_node, 'id'):
            return func_node.id

    def get_node_key(self, node):
        return f"{type(node).__module__}.{type(node).__qualname__}"

    def prevent_infintive_loop(self, method, node_type, node_id, info=""):
        stack_entry = f"{method}_{node_type}_{node_id}"
        if stack_entry in self.call_stack:
            raise Exception(f"Loop infinito detectado para {stack_entry}, info: {info}")
        self.call_stack.append(stack_entry)

    def resolve(self, node, exclusiones=[]):
        # self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))        

        if not isinstance(node, ast.Module):
            raise Exception("La clase root debe ser ast.Module")

        collector = CtxCollector(exclusiones=exclusiones)
        self.context = ModuleContext(key="root", collector=collector)
        self.resolve_module(node, self.context)
            
        
        excluded_obs = collector.exclude_all_obs()
        handled_errors = collector.get_handled_errors()
        return excluded_obs, handled_errors
    
    def resolve_statement(self, node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        if isinstance(node, ast.ImportFrom):
            result = self.resolve_import_from(node, context)
            return result

        if isinstance(node, ast.Call):
            result = self.resolve_call(node, context)            
            return result
        
        if isinstance(node, ast.FunctionDef):            
            result = self.resolve_function_def(node, context)
            return result  
        
        if isinstance(node, ast.ClassDef):
            result = self.resolve_class_def(node, context)
            return result
        
        if isinstance(node, ast.Assign):
            result = self.resolve_assign(node, context)
            return result   

        if isinstance(node, ast.Expr):
            self.resolve_expr(node, context)


    def resolve_module(self, node, context):                
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))        
        self.resolve_module_body(node.body, context=context)
        
    
    def resolve_module_body(self, statements, context):        
        for stmt in statements:    
            # self.global_stmt_lineno = stmt.lineno
            self.current_stmt = stmt
            self.func_name_list = []
            self.resolve_statement(stmt, context)

    def resolve_import_from(self, node_import_from, context):
        # tree = astpretty.pformat(node_import_from)        

        module = node_import_from.module
        names = node_import_from.names
        for alias in names:
            key = alias.name if alias.asname is None else alias.name            
            fullname = f"{module}.{alias.name}"            
            context.imports[key] = fullname


                
    def resolve_expr(self, node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        if isinstance(node.value, ast.Call):
            self.resolve_call(node.value, context)        
            
    def resolve_function_def(self, function_def_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(function_def_node).__name__, id(function_def_node))                                                
        if function_def_node.lineno == 147:
            pass

        function_context = FunctionContext(key=function_def_node.name, parent=context, collector=context.collector)
        self.resolve_function_def_body(function_def_node.body, function_context)
        returns = self.resolve_function_def_returns(function_def_node.returns)

        if "DataFrame" in function_context.returns:
            return_type = "DataFrame"
        else:
            return_type = returns 

        func_def_resp = FunctionDefResponse(
            lineno=function_def_node.lineno,
            context=function_context,
            func_name=function_def_node.name,
            returns=returns,
            return_type=return_type
        )
        context.func_defs[func_def_resp.func_name] = func_def_resp
        return func_def_resp

    def resolve_class_def(self, class_def_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(class_def_node).__name__, id(class_def_node))

        class_context = ClassContext(key=class_def_node.name, parent=context, collector=context.collector)
        
        class_def_resp = ClassDefResponse(
            lineno=class_def_node.lineno,
            context=class_context,
            class_name=class_def_node.name
        )
        context.class_defs[class_def_node.name] = class_def_resp
        self.resolve_class_def_body(class_def_node.body, class_context)

    
    def resolve_class_def_body(self, class_def_body, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(class_def_body).__name__, id(class_def_body))
        for node in class_def_body:
            if isinstance(node, ast.FunctionDef):
                self.resolve_function_def(node, context)
    
    def resolve_function_def_returns(self, func_def_returns_node, context=None):
        if isinstance(func_def_returns_node, ast.Name):
            return func_def_returns_node.id

    def resolve_function_def_body(self, body, context=None):
        for item_body in body:
            self.resolve_node(body, item_body, context)


    def resolve_node(self, parent_node, node, context=None):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))

        if parent_node is node:
            raise Exception(f"El nodo padre no puede ser el mismo que el del hijo")

        if isinstance(node, ast.Try):
            return self.resolve_try(node, context)

        if isinstance(node, ast.Assign):
            return self.resolve_assign(node, context)

        if isinstance(node, ast.Expr):
            return self.resolve_expr(node, context)
        
        if isinstance(node, ast.If):
            return self.resolve_if(node, context)

        if isinstance(node, ast.For):
            return self.resolve_for(node, context)
        
        if isinstance(node, ast.Return):
            return self.resolve_return(node, context)
    
        if isinstance(node, ast.Continue):
            return

        if isinstance(node, ast.Pass):
            return
        
        context.collector.add_error(node.lineno, f"Nodo {type(node).__name__} no soportado resolve_node")

    def resolve_if(self, if_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(if_node).__name__, id(if_node))

        for stmt in if_node.body:
            self.resolve_node(if_node, stmt, context)            

    def resolve_for(self, for_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(for_node).__name__, id(for_node))

        for_body = for_node.body
        for stmt in for_body:
            self.resolve_node(for_node, stmt, context)

    def resolve_try(self, try_node, context):        
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(try_node).__name__, id(try_node))

        self.resolve_try_body(try_node.body, context)

    def resolve_if_exp(self, if_exp_node:ast.IfExp, context):
        resp_if_exp_body = self.resolve_if_exp_body(if_exp_node.body, context)
        resp_if_exp_orelse = self.resolve_if_exp_orelse(if_exp_node.orelse, context)
        resp = IfExpResponse(
            body_source=resp_if_exp_body,
            orelse_source=resp_if_exp_orelse
        )
        return resp

    def resolve_if_exp_body(self, if_exp_body_node, context):
        if if_exp_body_node.lineno == 148:
            pass

        resp = None
        if isinstance(if_exp_body_node, ast.Name):
            resp = self.resolve_name(if_exp_body_node, context)
        elif isinstance(if_exp_body_node, ast.Constant):
            resp = self.resolve_constant(if_exp_body_node)
        elif isinstance(if_exp_body_node, ast.Str):
            resp = self.resolve_str(if_exp_body_node)
        elif isinstance(if_exp_body_node, ast.Num):
            resp = self.resolve_num(if_exp_body_node)
        elif isinstance(if_exp_body_node, ast.NameConstant):
            resp = self.resolve_name_constant(if_exp_body_node)
        else:
            context.collector.add_error(if_exp_body_node.lineno, f"{type(if_exp_body_node).__name__} no soportado en if_exp_body")
        return resp

    def resolve_if_exp_orelse(self, if_exp_orelse, context):
        resp = None
        if isinstance(if_exp_orelse, ast.Name):
            resp = self.resolve_name(if_exp_orelse, context)
        elif isinstance(if_exp_orelse, ast.Constant):
            resp = self.resolve_constant(if_exp_orelse)
        elif isinstance(if_exp_orelse, ast.Str):
            resp = self.resolve_str(if_exp_orelse)
        elif isinstance(if_exp_orelse, ast.Num):
            resp = self.resolve_num(if_exp_orelse)
        elif isinstance(if_exp_orelse, ast.NameConstant):
            resp = self.resolve_name_constant(if_exp_orelse)
        else:
            context.collector.add_error(if_exp_orelse.lineno, f"{type(if_exp_orelse).__name__} no soportado en if_exp_orelse")
        return resp        
    
    def resolve_return(self, return_node, context):
        if return_node.lineno == 148:
            pass

        resp = None
        if isinstance(return_node.value, ast.Constant):
            resp = self.resolve_constant(return_node.value)
        elif isinstance(return_node.value, ast.Str):
            resp = self.resolve_str(return_node.value)
        elif isinstance(return_node.value, ast.Num):
            resp = self.resolve_num(return_node.value)
        elif isinstance(return_node.value, ast.NameConstant):
            resp = self.resolve_name_constant(return_node.value)
        elif isinstance(return_node.value, ast.Call):
            resp = self.resolve_call(return_node.value, context)
        elif isinstance(return_node.value, ast.Name):
            resp = self.resolve_name(return_node.value, context)        
        elif isinstance(return_node.value, ast.IfExp):
            resp = self.resolve_if_exp(return_node.value, context)
        elif isinstance(return_node.value, ast.Attribute):
            resp = self.resolve_attribute(return_node.value, context)
        elif isinstance(return_node.value, ast.JoinedStr):
            resp = self.resolve_joined_str(return_node.value, context)
        else:
            context.collector.add_error(return_node.lineno, f"{type(return_node.value).__name__} no soportado en resolve_return")

        if not isinstance(resp, IfExpResponse):            
            return_resp = ReturnResponse(
                context=context,
                value_source=resp
            )
            # Añadir al contexto
            if return_resp.value_type is not None:
                context.returns[return_resp.value_type] = return_resp            

            return return_resp        
        else:
            return_body_val = ReturnResponse(
                context=context,
                value_type=resp.body_value_type
            )
            if return_body_val.value_type is not None:
                context.returns[return_body_val.value_type] = return_body_val

            return_orelse_val = ReturnResponse(
                context=context,
                value_type=resp.orelse_value_type
            )

            if return_orelse_val.value_type is not None:
                context.returns[return_orelse_val.value_type] = return_orelse_val

            return (return_body_val, return_orelse_val)            

    def resolve_try_body(self, try_body, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, "try_body", id(try_body))        

        for try_body_elem in try_body:
            if isinstance(try_body_elem, ast.Assign):
                self.resolve_assign(try_body_elem, context)                
            elif isinstance(try_body_elem, ast.Return):
                self.resolve_return(try_body_elem, context)            
            elif isinstance(try_body_elem, ast.Expr):
                self.resolve_expr(try_body_elem, context)
            else:
                self.context.collector.add_error(try_body_elem.lineno, f"{type(try_body_elem).__name__} no soportado en try_body")

    def add_func_name_list(self, func_name, lineno):        
        self.func_name_list.append({'name': func_name, 'lineno': lineno})

    def resolve_call(self, call_node, context) -> CallResponse:
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(call_node).__name__, id(call_node))                
        # self.add_to_dbutils_widgets()
        if call_node.lineno == 387:
            # print(call_node.lineno)
            pass

        nu_trace = [] 
        func = call_node.func
        func_name = self.get_func_name(func) 
        
        #NO CAMBIAR DE ORDEN add_func_name_list DEBE ESTAR DEBAJO DE args
        self.add_func_name_list(func_name,call_node.lineno)
        args, args_name, args_struct = self.resolve_call_args_valores(call_node.args, context)            
        keywords = self.resolve_call_keywords(call_node.keywords, context)
        
        for arg in args_struct:
            if isinstance(arg, CallResponse):           
                nu_trace = copy.copy(arg.trace)
                nu_trace.append(arg)           
            if isinstance(arg, NameResponse):
                nu_trace = copy.copy(arg.trace)
                nu_trace.append(arg)  
            
        if isinstance(func, ast.Attribute):
            result_attr = self.resolve_attribute(func, context)
            if result_attr is None:
                return
            nu_trace = copy.copy(result_attr.trace)
            nu_trace.append(result_attr) 
                            
            call_resp = self.resolve_call_from_attribute(call_node.lineno, result_attr, func_name, nu_trace, args, args_name,  keywords, context)                
            return call_resp
            
        if isinstance(func, ast.Name):
            name_resp = self.resolve_name(func, context)
            if name_resp is None:
                return None
                                
            nu_trace.append(name_resp)  

            resp = CallResponse(
                lineno=call_node.lineno,
                context=context,
                func_name=name_resp.var_name,
                return_type=name_resp.var_type,
                args=args,
                args_name=args_name,
                trace=nu_trace,
                keywords=keywords,
                dbutils=self.dbutils,
                func_name_list = self.func_name_list
            )
            
            return resp
                            
        return None    
    
    def resolve_call_from_attribute(self, lineno, attr:AttributeResponse, func_name, nu_trace, args, args_name, keywords, context):        
        resp = CallResponse(
            lineno=lineno,
            context=context,            
            attr_value=attr.value,
            attr_value_type=attr.value_type,                        
            attr_value_name=attr.value_name,
            func_name=func_name,                                         
            trace=nu_trace,
            args=args,
            args_name=args_name,
            keywords=keywords,
            dbutils=self.dbutils
        )
        
        return resp
    
    def resolve_call_attribute_attr(self, node):
        resultado = ""
        try:
            if isinstance(node, ast.Call):
                if (isinstance(node.func, ast.Attribute) and
                    isinstance(node.func.value, ast.Attribute) and
                    isinstance(node.func.value.value, ast.Name)):
                    id = node.func.value.value.id
                    attr1 = node.func.value.attr
                    attr2 = node.func.attr
                    resultado =  attr1 + "." + attr2
        except AttributeError as e:
            print(f"resolve_call_attribute_attr Error processing node:{node.lineno} {e}")
        except Exception as e:
            print(f"resolve_call_attribute_attr Unexpected error:{node.lineno} {e}")
        return resultado
        
    
    def resolve_assign(self, assign_node, context) -> AssignResponse:
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(assign_node).__name__, id(assign_node))

        targets = self.resolve_assign_targets(assign_node.targets, context)

        # print(assign_node)
        value = assign_node.value
        attr_name = self.resolve_call_attribute_attr(value)
        #print(assign_node.lineno, type(value).__name__)
        response = self.resolve_assign_value(value, context)
        

        
        if response is None:
            context.collector.add_error(value.lineno, f"No se ha podido recuperar el valor para los targets {str(targets)}")
            return None

        #fill obj   
        for target_id in targets:

            nu_assigns = []
            # val_type, value = response         
            assign_resp = AssignResponse(
                lineno = assign_node.lineno,
                context=context,                
                target_id=target_id,
                value_source=response
            ) 
            nu_assigns.append(assign_resp)
            return nu_assigns
        
        # Si no ha sido llamado se registra la asignacion como global
        # self.set_assigns(assign_resp=assign_resp)
        # return assign_resp

    def resolve_assign_targets(self, targets, context):
        resolved_targets = []
        for target in targets:            
            target_id = None
            if isinstance(target, ast.Tuple):
                for elt_item in target.elts:
                    if isinstance(elt_item, ast.Name):
                        target_id = elt_item.id
                    else:
                        context.collector.add_error(elt_item.lineno, f"{type(elt_item).__name__} no soportado en resolve_assign_targets")              

            if isinstance(target, ast.Name):
                target_id = target.id

            resolved_targets.append(target_id)

        return resolved_targets
    
    def resolve_call_args(self, args=[], context=None):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(args).__name__, id(args))

        arg_values = []
        for arg in args:
            arg_val = self.resolve_item(arg, context)
            arg_values.append(arg_val)
        return arg_values
    
    def resolve_call_args_valores(self, args=[], context=None):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(args).__name__, id(args))

        args_list = []
        args_name_list = []
        args_struct_list = []
        
        for arg in args:
            arg_val = self.resolve_item_valores(arg, context)
            if arg_val is None:
                args_list.append(None)
                args_name_list.append(None)
                args_struct_list.append(None)
            else:
                args_list.append(arg_val.get('arg_val'))
                args_name_list.append(arg_val.get('arg_name'))
                args_struct_list.append(arg_val.get('Estructura'))

        return args_list, args_name_list, args_struct_list
    
    def resolve_call_keywords(self, keywords=[], context=None):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(keywords).__name__, id(keywords))
        normalized_keywords = {}
        for keyword_node in keywords:
            arg, value = self.resolve_keyword(keyword_node, context)
            normalized_keywords[arg] = value        
        return normalized_keywords    
    
    def resolve_keyword(self, keyword_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(keyword_node).__name__, id(keyword_node))
        arg = keyword_node.arg
        value = None

        if isinstance(keyword_node.value, ast.Constant):
            value = self.resolve_constant(keyword_node.value)
        elif isinstance(keyword_node.value, ast.Str):
            value = self.resolve_str(keyword_node.value)
        elif isinstance(keyword_node.value, ast.Num):
            value = self.resolve_num(keyword_node.value)
        elif isinstance(keyword_node.value, ast.NameConstant):
            value = self.resolve_name_constant(keyword_node.value)
        elif isinstance(keyword_node.value, ast.Attribute):
            value = self.resolve_attribute(keyword_node.value, context)
        elif isinstance(keyword_node.value, ast.Name):
            value = self.resolve_name(keyword_node.value, context)
        else:
            self.context.collector.add_error(keyword_node.value.lineno, f"{type(keyword_node.value).__name__} no soportado en resolve_keyword, data {str(keyword_node.__dict__)}")

        return (arg, value)
    
    def resolve_item(self, item_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(item_node).__name__, id(item_node))
        if isinstance(item_node, ast.JoinedStr):
            result = self.resolve_joined_str(item_node, context)
            return result

        elif isinstance(item_node, ast.Call):
            result_call = self.resolve_call(item_node, context)
            if result_call is None:
                return None
            
            return result_call.return_val
        
        elif isinstance(item_node, ast.Name):
            resp_name = self.resolve_name(item_node, context)
            if resp_name is None:
                return None
            
            return resp_name.var_value
        elif isinstance(item_node, ast.Str):
            resp = self.resolve_str(item_node)
            return resp
                
        elif hasattr(item_node, "value"):
            return item_node.value            
        
        # si hay llegado hasta aqui es que hay un token no soportado
        context.collector.add_error(item_node.lineno, f"{type(item_node).__name__} no soportado en resolve_item")

    def resolve_item_valores(self, item_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(item_node).__name__, id(item_node))
        
        if isinstance(item_node, ast.JoinedStr):
            result = self.resolve_joined_str_valores(item_node, context)
            return result
        
        elif isinstance(item_node, ast.Call):
            result_call = self.resolve_call(item_node, context)
            if result_call is None:
                return None  
            return {"arg_val": result_call.return_val, "arg_name": None, 'Estructura':result_call}
        
        elif isinstance(item_node, ast.Name):
            resp_name = self.resolve_name(item_node, context)
            if resp_name is None:
                return None                                 
            return {"arg_val": resp_name.var_value, "arg_name": resp_name.var_name, 'Estructura':resp_name}
     
        elif isinstance(item_node, ast.Str):
            resp = self.resolve_str(item_node)            
            return {"arg_val": resp, "arg_name": resp, 'Estructura':None}
        elif isinstance(item_node, ast.Num):
            resp = self.resolve_num(item_node)
            return {"arg_val": resp, "arg_name": resp, 'Estructura': None}
        elif hasattr(item_node, "value"):            
            return {"arg_val": item_node.value, "arg_name": item_node.value, 'Estructura':None}
 
        # si hay llegado hasta aqui es que hay un token no soportado
        context.collector.add_error(item_node.lineno, f"{type(item_node).__name__} no soportado en resolve_item_valores")
        return {"arg_val": None, "arg_name": None, 'Estructura':None}
        
    
    def resolve_assign_value(self, value_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(value_node).__name__, id(value_node))
        # response = (value_type, value_resolved)
        response = None
        if isinstance(value_node, ast.Call):
            result = self.resolve_call(value_node, context)              
            if result is not None:                
                return (result.return_type, result.return_val)
        
        if isinstance(value_node, ast.JoinedStr):
            result = self.resolve_joined_str(value_node, context)
            if result is not None:
                return (ReturnType.STRING.value, result)

        if isinstance(value_node, ast.Subscript):
            result = self.resolve_subscript(value_node, context)
            if result is not None:
                return (ReturnType.STRING.value, result)

        if isinstance(value_node, ast.List):
            result = self.resolve_list(value_node, context)  
            if result is not None:
                return (ReturnType.LIST.value, result)  
        
        if isinstance(value_node, ast.Constant):
            result = self.resolve_constant(value_node)
            if result is not None:
                return (ReturnType.STRING.value, result)
            
        if isinstance(value_node, ast.Attribute):
            result = self.resolve_attribute(value_node, context)
            if result is not None:
                return (AttributeResponse, result)    

        if isinstance(value_node, ast.BinOp):
            result = self.resolve_bin_op(value_node, context)
            if result is not None:
                return (BinOpResponse, result)
            
        if isinstance(value_node, ast.Str):            
            result = self.resolve_str(value_node)
            if result is not None:                
                return (ReturnType.STRING.value, result)
            
        if isinstance(value_node, ast.Num):            
            result = self.resolve_num(value_node)
            if result is not None:                
                return (ReturnType.NUMERIC.value, result)
    
        return response

    def resolve_list(self, node_list, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node_list).__name__, id(node_list))
        clean_list = []
        for element in node_list.elts:
            if isinstance(element, ast.Constant):
                val = self.resolve_constant(element)                                    
                clean_list.append(val)
            elif isinstance(element, ast.Str):
                val = self.resolve_str(element)
                clean_list.append(val)
            elif isinstance(element, ast.Num):
                val = self.resolve_num(element)
                clean_list.append(val)
            else:
                clean_list.append(element)

        return clean_list

    def resolve_subscript(self, node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        slice_resolved = self.resolve_subscript_slice(node.slice, context)
        value_resolved = self.resolve_subscript_value(node.value, context)

        subs = SubscriptResponse(
            lineno=node.lineno,
            context=context,
            slice_source=slice_resolved,
            value_source=value_resolved
        )

        return subs

    def resolve_bin_op(self, node, context):     
        left=self.resolve_bin_op_left(node.left, context)
        right=self.resolve_bin_op_right(node.right, context)
        resp = BinOpResponse(
            lineno=node.lineno,
            context=context,
            left_source=left,
            right_source=right,    
            op=node.op
        )
        return resp

    def resolve_bin_op_left(self, node, context):
        if isinstance(node, ast.Subscript):
            return self.resolve_subscript(node, context)
        else:
            context.collector.add_error(node.lineno, "BinOp left no soportado")

    def resolve_bin_op_right(self, node, context):
        if isinstance(node, ast.Subscript):
            return self.resolve_subscript(node, context)
        else:
            context.collector.add_error(node.lineno, "BinOp right no soportado")

 

    def resolve_subscript_slice(self, subscript_slice_node, context):
        if isinstance(subscript_slice_node, ast.Constant):
            result = self.resolve_constant(subscript_slice_node)
            return result
        
        if isinstance(subscript_slice_node, ast.Slice):
            result = self.resolve_slice(subscript_slice_node, context)
            return result

        if isinstance(subscript_slice_node, ast.Index):
            result = self.resolve_index(subscript_slice_node, context)
            return result
        
        #print(astpretty.pformat(subscript_slice_node, indent=4))
        lineno = 0 if not hasattr(subscript_slice_node, "lineno") else subscript_slice_node.lineno
        context.collector.add_error(lineno, f"{type(subscript_slice_node).__name__} slice no soportado")
        return None
    
    def resolve_index(self, index_node, context):
        resp = None
        value_node = index_node.value
        if isinstance(value_node, ast.Num):
            resp = self.resolve_num(value_node)
        else:                
            lineno = 0 if not hasattr(value_node, "lineno") else value_node.lineno
            context.collector.add_error(lineno, f"{type(value_node).__name__} Index.value no soportado")        
        return resp



    def resolve_subscript_value(self, subscript_value_node, context):
        if subscript_value_node.lineno == 106:
            pass

        if isinstance(subscript_value_node, ast.Call):
            call_resp = self.resolve_call(subscript_value_node, context)
            return call_resp

        if isinstance(subscript_value_node, ast.Name):
            name_resp = self.resolve_name(subscript_value_node, context)
            return name_resp            

        context.collector.add_error(subscript_value_node.lineno, "subscript_value no soportado")
        return None
        
    
    def resolve_slice(self, node, context):
        lower = self.resolve_slice_lower(node.lower, context)
        upper = self.resolve_slice_upper(node.upper, context)
        step = self.resolve_slice_step(node.step, context)
        resp = SliceResponse(
            lower=lower,
            upper=upper,
            step=step
        )
        return resp

    def resolve_slice_lower(self, node, context):
        if node is None:
            return
        
        if isinstance(node, ast.Constant):
            resp = self.resolve_constant(node)
            return resp
        elif isinstance(node, ast.Num):
            resp = self.resolve_num(node)
            return resp
        elif isinstance(node, ast.Name):
            resp = self.resolve_name(node, context)
            return resp
        else:
            context.collector.add_error(node.lineno, f"lower, {type(node).__name__} tipo no soportado")

    def resolve_slice_upper(self, node, context):
        if node is None:
            return
        
        if isinstance(node, ast.Constant):
            resp = self.resolve_constant(node)
            return resp
        elif isinstance(node, ast.Num):
            resp = self.resolve_num(node)
            return resp
        elif isinstance(node, ast.Name):
            resp = self.resolve_name(node, context)
            return resp
        else:
            context.collector.add_error(node.lineno, f"upper, {type(node).__name__} tipo no soportado")

    def resolve_slice_step(self, node, context):
        if node is None:
            return
        
        if isinstance(node, ast.Constant):
            resp = self.resolve_constant(node)
            return resp
        elif isinstance(node, ast.Num):
            resp = self.resolve_num(node)
            return resp
        else:
            context.collector.add_error(node.lineno, f"step, {type(node).__name__} tipo no soportado")


    def _slice(self, slice_node, in_str):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(slice_node).__name__, id(slice_node))
        if in_str is None:
            return ""
        
        lower = slice_node.lower
        if lower is not None:  
            if isinstance(lower, ast.Num):
                lower_num = self.resolve_num(lower)
            if isinstance(lower, ast.Constant):
                lower_num = self.resolve_constant(lower)

        upper = slice_node.upper
        if upper is not None:
            if isinstance(upper, ast.Constant):
                upper_num = self.resolve_constant(upper)
            if isinstance(upper, ast.Num):
                upper_num = self.resolve_num(upper)

        if lower is None and upper is not None:
            sliced_text = in_str[:upper_num]
            return sliced_text

        if lower is not None and upper is None:
            sliced_text = in_str[lower_num:]
            return sliced_text

        if lower is None and upper is None:
            return ""
                        
        sliced_text = in_str[lower_num:upper_num]
        return sliced_text
    
    def resolve_joined_str_valores(self, node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        parts = []
        partsname = [] 
        resp_value = ""
        resp_name = ""
        for part in node.values:            
            if isinstance(part, ast.Constant):
                const_val = self.resolve_constant(part)
                parts.append(const_val) 
                partsname.append(const_val)

            elif isinstance(part, ast.FormattedValue):
                fmtd_value = self.resolve_formatted_valores(part,context)
                if fmtd_value is None:
                    parts.append(fmtd_value) 
                    partsname.append(fmtd_value) 
                else:
                    parts.append(fmtd_value.var_value) 
                    partsname.append(fmtd_value.var_name)

            elif isinstance(part, ast.Str):
                str_val = self.resolve_str(part)
                parts.append(str_val)
                partsname.append(str_val)

            elif isinstance(part, ast.Num):
                num_val = self.resolve_num(part)
                parts.append(str(num_val))
                partsname.append(str(num_val))
            else:
                context.collector.add_error(node.lineno, f"{type(part).__name__} no soportado en resolve_joined_str_valores")
  
        try:
            nu_parts = [part for part in parts if part is not None] 
            resp_value = "".join(nu_parts)

            nu_partsname = [part for part in partsname if part is not None] 
            resp_name = "".join(nu_partsname)
    
        except Exception as e:
            context.collector.add_error(node.lineno, f"Error al unir partes: {str(e)}")
            return {"arg_val": None, "arg_name": None, 'Estructura':None}
            
        return {"arg_val": resp_value, "arg_name": resp_name, 'Estructura':None}

    def resolve_joined_str(self, node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        parts = []
        resp_text = ""
        for part in node.values:            
            if isinstance(part, ast.Constant):
                const_val = self.resolve_constant(part)
                parts.append(const_val)

            elif isinstance(part, ast.FormattedValue):
                fmtd_value = self.resolve_formatted_value(part, context)
                parts.append(fmtd_value)            

            elif isinstance(part, ast.Str):
                str_val = self.resolve_str(part)
                parts.append(str_val)

            elif isinstance(part, ast.Num):
                num_val = self.resolve_num(part)
                parts.append(str(num_val))
            else:
                context.collector.add_error(node.lineno, f"{type(part).__name__} no soportado en resolve_joined_str")

        try:
            nu_parts = [part for part in parts if part is not None] 
            resp_text = "".join(nu_parts)
        except:
            context.collector.add_error(node.lineno, "Analyzer - resolve_joined_str: algunas partes no son strings para unir")            

        return resp_text

    def resolve_constant(self, node):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        return node.value
    
    def resolve_str(self, node):
        return node.s
    
    def resolve_num(self, node):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        return node.n
    
    def resolve_name_constant(self, node):
        if not isinstance(node, ast.NameConstant):
            return node.value


    def resolve_formatted_value(self, node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        if isinstance(node.value, ast.Name):            
            result = self.resolve_name(node.value, context)
            if result is None:
                return None
            
            value = result.var_value
            return value
        
    def resolve_formatted_valores(self, node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(node).__name__, id(node))
        if isinstance(node.value, ast.Name):            
            result = self.resolve_name(node.value, context)
            if result is None:
                return None            
                         
            return result

    def resolve_attribute(self, attribute_node, context:ModuleContext)->AttributeResponse:
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(attribute_node).__name__, id(attribute_node))
        response = AttributeResponse()
        lineno = attribute_node.lineno
        attr_name = attribute_node.attr        
        value = attribute_node.value

        # Utilizamos el helper del collecto para que identifique si se esta usando la propiedad rdd
        AttributeCollector.collect_property_rdd(context.collector, attribute_node)
        
        
        if isinstance(value, ast.Call):
            call_result = self.resolve_call(value, context)
            if call_result is None:
                return None
            
            nu_trace = copy.copy(call_result.trace)
            nu_trace.append(call_result)            

            if call_result is not None:                
                response = AttributeResponse(
                    context=context,
                    lineno=lineno,                    
                    value=call_result.return_val,
                    value_type=call_result.return_type,
                    attr=attr_name,
                    trace=nu_trace
                )                            
                return response
            return None
        
        # WidgetsUtils

        if isinstance(value, ast.Name):            
            resp_name = self.resolve_name(value, context)
            if resp_name is None:
                return None
            
            response = AttributeResponse(
                value=resp_name.var_value,
                value_type=resp_name.var_type,
                value_name=resp_name.var_name,
                attr=attr_name,                    
                trace=[resp_name]
            )  
                        
            return response

        if isinstance(value, ast.Constant):
            resp_cons = self.resolve_constant(value)
            
            response = AttributeResponse(                
                value_type=ReturnType.STRING.value, 
                value=resp_cons,
                attr=attr_name,                    
                trace=[resp_cons]
            )  
                        
            return response
        
        if isinstance(value, ast.Str):
            resp_str = self.resolve_str(value)
            response = AttributeResponse(
                value_type=ReturnType.STRING.value, 
                value=resp_str,
                attr=attr_name,                    
                trace=[resp_str]
            )
            return response

        if isinstance(value, ast.Num):
            resp_num = self.resolve_num(value)
            response = AttributeResponse(
                value_type=ReturnType.NUMERIC.value, 
                value=resp_num,
                attr=attr_name,                    
                trace=[resp_num]
            )
            return response                
        
        if isinstance(value, ast.Attribute):
            attr_result = self.resolve_attribute(value, context)            

            if attr_result is None:
                return None
            
            nu_trace = copy.copy(attr_result.trace)
            nu_trace.append(attr_result)
                    
            response = AttributeResponse(
                value_type=attr_result.return_type,
                attr=attr_name,
                trace=nu_trace
            ) 
            return response
        
        if isinstance(value, ast.Subscript):
            return self.resolve_attribute_value_from_subscript(value, context)
        
        self.context.collector.add_error(attribute_node.lineno, f"resolve_attribute, {type(value).__name__} no soportado")

    def resolve_attribute_value_from_subscript(self, value_node, context):
        if not isinstance(value_node, ast.Subscript):
            raise Exception(f"El nodo valor del atributo no es un ast.Subscript, lineno: {value_node.lineno}")
        
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(value_node).__name__, id(value_node))
        resp_subscript = self.resolve_subscript(value_node, context)
        

            
    def resolve_name(self, name_node, context):
        self.prevent_infintive_loop(sys._getframe().f_code.co_name, type(name_node).__name__, id(name_node))
        var_name = name_node.id

        resp = NameResponse(
            context=context,
            var_name=var_name
        )

        return resp

        """
        if var_name == "self":
            resp = NameResponse(
                context=context,
                var_name=var_name
            )
            return resp

        # Buscamos si el nombre de la variable esta en los nombres estandar
        if var_name in NameHelper.CONFIG:
            var_type, callback = NameHelper.CONFIG.get(var_name)
            resp = NameResponse(
                var_name=var_name,
                var_type=var_type
            )
            return resp            
        
        # Buscar en variables
        target = context.get_target(var_name)
        if target is not None:
            assign, hist = target
            resp = NameResponse(
                var_name=var_name,
                var_type=assign.value_type,
                var_value=assign.value                
            )
            return resp            
        
        # Buscar en definiciones de funciones
        func_def = context.get_func_def(var_name)
        if func_def is not None:
            resp = NameResponse(
                var_name=var_name,
                var_type=func_def.return_type         
            )
            return resp
        
        resp = NameResponse(
            var_name=var_name
        )
        
        # raise Exception(f"No se ha encontrado una referencia en targets o definiciones de funciones para {var_name}")
        return resp
        """

class ExclusionAnalyzer:
    def __init__(self, exclude_linenum, granted_exclusions):
        self.exclude_linenum = exclude_linenum
        self.exclusions = granted_exclusions
    
    @staticmethod
    def eval_line_code(linenum, linecode):
        exclude_linenum = linenum
        linecodework = linecode.strip()
        pos_found = linecodework.find(CONST_TEXT_EXCLUDE_ANALYZER)

        # El comentario no debe tener nada al inicio
        if pos_found != 0:
            return None
        
        # Quitamos el texto marcador
        linecodework = linecodework.replace(CONST_TEXT_EXCLUDE_ANALYZER,"")
        linecodework = linecodework.strip()

        # obtenemos las exclusiones
        required_exclusions = linecodework.split(",")
        granted_exclusions = []
        for elem in required_exclusions:
            exclusion = elem.strip()
            if exclusion not in CONST_CONFIG_RULES_TOKEN_EXCLUSION_INDEXED:
                continue
            else:
                granted_exclusions.append(exclusion)
        
        return ExclusionAnalyzer(
            exclude_linenum,
            granted_exclusions
        )


class AnalyzerCore:    
    def analizar(self, content, global_exclusions, exclusions):              
        # global_exclusions, exclusiones = self.get_exclusiones(content)  
        

        tree = ast.parse(content)    
        """
        with open("output/dump.txt","w") as f:
            f.write(ast.dump(tree, indent=4))
        """

        resolver = Resolver()
        obs, handled_errors = resolver.resolve(tree, exclusiones=exclusions)                
        obs = self.exclude_globals(obs, global_exclusions)                        
        return obs, handled_errors
    
    def exclude_globals(self, obs, rule_keys_to_exclude):
        for rule_key in rule_keys_to_exclude:
            obs[rule_key] = []
        return obs
        
    def get_exclusiones(self, content):        
        exclusiones = []
        global_exclusiones = []
        lines = content.splitlines()
        prev_line_of_code = 0
        for linenum, linecode in enumerate(lines, 1):            
            # Buscamos las exclusiones globales
            if linecode.strip() == "":
                continue
            elif linecode.strip().startswith("#") and prev_line_of_code == 0 and len(global_exclusiones) == 0:                             
                global_exclusiones = self.find_global_exclusions(linenum, linecode)
            elif not linecode.strip().startswith("#") :
                prev_line_of_code = linenum

            # Buscamos las exclusiones por linea
            exclusion = ExclusionAnalyzer.eval_line_code(linenum, linecode)
            if exclusion is not None:
                exclusiones.append(exclusion)

        return global_exclusiones, exclusiones    
    
    def find_global_exclusions(self, linenum, linecode):

        # Si la linea no esta comentada buscamos las exclusiones globales
        exclude_linenum = linenum
        linecodework = linecode.strip()
        pos_found = linecodework.find(CONST_TEXT_EXCLUDE_ANALYZER_GLOBAL)

        # El comentario no debe tener nada al inicio
        if pos_found != 0:
            return []
        
        # Quitamos el texto marcador
        linecodework = linecodework.replace(CONST_TEXT_EXCLUDE_ANALYZER_GLOBAL,"")
        linecodework = linecodework.strip()

        # obtenemos las exclusiones
        required_exclusions = linecodework.split(",")
        granted_exclusions = []
        for elem in required_exclusions:
            exclusion_token = elem.strip()
            if exclusion_token not in CONST_CONFIG_RULES_TOKEN_EXCLUSION_GLOBAL_INDEXED:
                continue
            else:
                # exclusion_rule = CONST_CONFIG_RULES_TOKEN_EXCLUSION_GLOBAL_INDEXED.get(exclusion_token)
                granted_exclusions.append(exclusion_token)

        unique_granted_exclusions = list(set(granted_exclusions))
        return unique_granted_exclusions
